(function (e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });

  var V = valenced;
  var safe = function (f, d) {
    try {
      var r = f();
      return r === undefined ? d : r;
    } catch (_) {
      return d;
    }
  };
  var norm = function (m) {
    return m && m.default && typeof m.default !== "string" && !m.createElement && !m.View ? m.default : m;
  };

  var F = V.modules.finders;
  var find = function () {
    var p = Array.prototype.slice.call(arguments);
    return safe(function () {
      return F.lookupModule(F.filters.withProps.apply(null, p))[0];
    });
  };

  // ===== الوحدات =====
  var Stores = new Proxy({}, { get: function (_, k) { return V.discord.flux.Stores[k]; } });
  var Dispatcher = safe(function () { return V.discord.common.flux.Dispatcher; });
  var Toast = safe(function () { return V.discord.actions.ToastActionCreators; });
  var httpCache = null;
  var getHTTP = function () {
    if (httpCache) return httpCache;
    var m = find("HTTP", "post");
    var h = (m && m.HTTP) || find("getAPIBaseURL", "get", "patch");
    if (!h || !h.get) throw new Error("HTTP module not found");
    httpCache = h;
    return h;
  };
  var HTTP = {
    get: function (o) { return getHTTP().get(o); },
    patch: function (o) { return getHTTP().patch(o); },
  };

  var uiCache = null;
  var ui = function () {
    if (uiCache) return uiCache;
    var R = norm(safe(function () { return V.externals.React; })) || find("createElement", "useState");
    var RN = norm(safe(function () { return V.externals.ReactNative; })) || find("View", "Text", "ScrollView");
    var dm = safe(function () { return V.discord.design; });
    var D = dm && (dm.Design || dm);
    var Page = norm(safe(function () { return V.components.Page; }));
    var okType = function (x) { return typeof x === "function" || (x && typeof x === "object" && x.$$typeof); };
    if (!okType(Page)) Page = null;
    if (!R) throw new Error("React not found");
    if (!RN) throw new Error("ReactNative not found");
    if (!D) throw new Error("Design components not found");
    uiCache = { R: R, RN: RN, D: D, Page: Page };
    return uiCache;
  };

  // ===== التخزين =====
  var DEFAULTS = { profiles: {}, ns: { enabled: false, names: [] } };
  var store = null;
  var mirror = DEFAULTS;

  var getState = function () {
    var s = safe(function () { return store && store.cache ? store.cache : undefined; });
    s = s || safe(function () { return store && typeof store.get === "function" ? store.get() : undefined; });
    s = s || mirror;
    return Object.assign({}, DEFAULTS, s, {
      profiles: (s && s.profiles) || {},
      ns: Object.assign({}, DEFAULTS.ns, (s && s.ns) || {}),
    });
  };
  var setState = function (patch) {
    mirror = Object.assign({}, getState(), patch);
    if (store && typeof store.set === "function") store.set(patch);
  };

  // ===== أدوات =====
  var toast = function (t) {
    safe(function () {
      Toast.open("per-profile", { text: String(t).slice(0, 120) });
    });
  };

  var errText = function (err) {
    try {
      var b = (err && err.body) || err;
      return (((err && err.status) || "") + " " + (JSON.stringify(b) || (err && err.message) || err)).slice(0, 400);
    } catch (_) {
      return String(err);
    }
  };

  var clean = function (o) {
    var out = {};
    Object.keys(o).forEach(function (k) {
      if (o[k] !== null && o[k] !== undefined) out[k] = o[k];
    });
    return out;
  };

  var ext = function (hash) { return String(hash).indexOf("a_") === 0 ? "gif" : "png"; };

  var toDataURI = async function (url) {
    var blob = await (await fetch(url)).blob();
    return await new Promise(function (res, rej) {
      var r = new FileReader();
      r.onloadend = function () { res(r.result); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  };

  var currentGuildId = function () {
    return safe(function () { return Stores.SelectedGuildStore.getGuildId(); });
  };
  var me = function () { return Stores.UserStore.getCurrentUser(); };

  var fetchProfile = function (userId, guildId) {
    return HTTP.get({
      url: "/users/" + userId + "/profile?with_mutual_guilds=false&guild_id=" + guildId,
    });
  };

  // ===== قراءة البيانات =====
  var effId = function (x) {
    return x ? (x.sku_id != null ? x.sku_id : x.skuId != null ? x.skuId : x.id != null ? x.id : null) : null;
  };

  var readEffect = function (body) {
    var p = body.guild_member_profile || {};
    var up = body.user_profile || {};
    var r = effId(p.profile_effect);
    if (r == null) r = p.profile_effect_id;
    if (r == null) r = effId(up.profile_effect);
    if (r == null) r = up.profile_effect_id;
    return r == null ? null : r;
  };

  var readGuildDecoration = function (body) {
    var src = body.guild_member && body.guild_member.avatar_decoration_data;
    if (!src || !src.asset) return null;
    return { asset: src.asset, sku_id: src.sku_id != null ? src.sku_id : src.skuId != null ? src.skuId : null };
  };

  var readNameStyle = function (body) {
    var pick = function (s) {
      if (!s || typeof s !== "object") return null;
      var has = s.font_id != null || s.effect_id != null || (Array.isArray(s.colors) && s.colors.length > 0);
      return has ? s : null;
    };
    return pick(body.guild_member && body.guild_member.display_name_styles) ||
      pick(body.user && body.user.display_name_styles) || null;
  };

  var sameStyle = function (a, b) {
    var n = function (s) {
      return JSON.stringify([s && s.font_id != null ? s.font_id : null, s && s.effect_id != null ? s.effect_id : null, (s && s.colors) || []]);
    };
    return n(a) === n(b);
  };

  var buildData = async function (body, userId, guildId, withNick) {
    var p = body.guild_member_profile || {};
    var m = body.guild_member || {};
    var u = body.user || {};
    var up = body.user_profile || {};

    var avatarUrl = null;
    var avatarSrc = "ما فيه";
    var cu = safe(function () { return Stores.UserStore.getUser(userId); });
    var avatarHash = u.avatar || (cu && cu.avatar);
    if (m.avatar) {
      avatarUrl = "https://cdn.discordapp.com/guilds/" + guildId + "/users/" + userId + "/avatars/" + m.avatar + "." + ext(m.avatar) + "?size=1024";
      avatarSrc = "خاص بالسيرفر";
    } else if (avatarHash) {
      avatarUrl = "https://cdn.discordapp.com/avatars/" + userId + "/" + avatarHash + "." + ext(avatarHash) + "?size=1024";
      avatarSrc = "عام";
    }

    var bannerUrl = null;
    if (p.banner) {
      bannerUrl = "https://cdn.discordapp.com/guilds/" + guildId + "/users/" + userId + "/banners/" + p.banner + "." + ext(p.banner) + "?size=1024";
    } else if (u.banner || up.banner) {
      var bh = u.banner || up.banner;
      bannerUrl = "https://cdn.discordapp.com/banners/" + userId + "/" + bh + "." + ext(bh) + "?size=1024";
    }

    var pick = function (a, b) { return a != null ? a : b; };
    var data = {
      bio: pick(p.bio, pick(up.bio, "")),
      pronouns: pick(p.pronouns, pick(up.pronouns, "")),
      accent_color: pick(p.accent_color, pick(up.accent_color, pick(u.accent_color, null))),
      theme_colors: pick(p.theme_colors, pick(up.theme_colors, null)),
      profile_effect_id: readEffect(body),
      avatar_decoration: readGuildDecoration(body),
      display_name_styles: readNameStyle(body),
      nick: withNick ? (m.nick != null ? m.nick : null) : null,
      avatarUrl: avatarUrl,
      bannerUrl: bannerUrl,
      avatar: avatarUrl ? await toDataURI(avatarUrl) : null,
      banner: bannerUrl ? await toDataURI(bannerUrl) : null,
    };
    return { data: data, avatarSrc: avatarSrc };
  };

  var summary = function (d) {
    return [
      d.avatar ? "أفتار" : null,
      d.banner ? "بنر" : null,
      d.profile_effect_id ? "افكت" : null,
      d.avatar_decoration ? "ديكوريشن" : null,
      d.display_name_styles ? "ستايل اسم" : null,
      d.bio ? "بايو" : null,
      d.nick ? "اسم: " + d.nick : null,
    ].filter(Boolean).join(" • ") || "فاضي";
  };

  // ===== التطبيق =====
  var applyProfile = async function (d, guildId) {
    var notes = [];
    var meId = me().id;

    if (d.nick) {
      try {
        await HTTP.patch({ url: "/guilds/" + guildId + "/members/@me", body: { nick: d.nick } });
      } catch (err) {
        if (!(err && err.body && err.body.code === 50013)) notes.push("النك نيم: " + errText(err));
      }
    }

    if (d.avatar) {
      try {
        await HTTP.patch({ url: "/guilds/" + guildId + "/members/@me", body: { avatar: d.avatar } });
      } catch (err) {
        notes.push(
          JSON.stringify((err && err.body) || "").indexOf("AVATAR_RATE_LIMIT") >= 0
            ? "الأفتار: ديسكورد يحدّ التغيير، جرّب بعد 10-15 دقيقة"
            : "الأفتار: " + errText(err)
        );
      }
    }

    if (d.display_name_styles) {
      var st = d.display_name_styles;
      try {
        await HTTP.patch({
          url: "/guilds/" + guildId + "/members/@me",
          body: clean({
            display_name_font_id: st.font_id,
            display_name_effect_id: st.effect_id,
            display_name_colors: st.colors,
          }),
        });
        var r1 = await fetchProfile(meId, guildId);
        if (!sameStyle(readNameStyle(r1.body), st)) notes.push("ستايل الاسم: ما تغيّر (غالباً ما تملك الخط أو التأثير)");
      } catch (err) {
        notes.push("ستايل الاسم: " + errText(err));
      }
    }

    try {
      await HTTP.patch({
        url: "/guilds/" + guildId + "/profile/@me",
        body: clean({
          bio: d.bio,
          pronouns: d.pronouns,
          banner: d.banner,
          accent_color: d.accent_color,
          theme_colors: d.theme_colors,
        }),
      });
    } catch (err) {
      notes.push("البنر/الألوان/البايو: " + errText(err));
    }

    if (d.profile_effect_id) {
      try {
        await HTTP.patch({
          url: "/guilds/" + guildId + "/profile/@me",
          body: { collectibles_sku_ids: [String(d.profile_effect_id)] },
        });
        var r2 = await fetchProfile(meId, guildId);
        var got = readEffect(r2.body);
        if (String(got) !== String(d.profile_effect_id)) notes.push("الافكت: ما تغيّر (الحالي " + (got != null ? got : "ما فيه") + ")");
      } catch (err) {
        notes.push("الافكت: " + errText(err));
      }
    }

    if (d.avatar_decoration && d.avatar_decoration.asset) {
      var dec = d.avatar_decoration;
      var ids = [dec.sku_id, d.profile_effect_id].filter(Boolean).map(String);
      var attempts = [];
      if (dec.sku_id) attempts.push({ url: "/guilds/" + guildId + "/profile/@me", body: { collectibles_sku_ids: ids } });
      attempts.push(
        { url: "/guilds/" + guildId + "/members/@me", body: { avatar_decoration_id: dec.sku_id != null ? dec.sku_id : dec.asset, avatar_decoration_sku_id: dec.sku_id } },
        { url: "/guilds/" + guildId + "/members/@me", body: { avatar_decoration_data: { asset: dec.asset, sku_id: dec.sku_id } } },
        { url: "/guilds/" + guildId + "/profile/@me", body: { avatar_decoration_data: { asset: dec.asset, sku_id: dec.sku_id } } }
      );
      var done = false;
      var lastErr = null;
      for (var i = 0; i < attempts.length; i++) {
        try {
          await HTTP.patch({ url: attempts[i].url, body: clean(attempts[i].body) });
          var r3 = await fetchProfile(meId, guildId);
          var gd = readGuildDecoration(r3.body);
          if (gd && gd.asset === dec.asset) { done = true; break; }
        } catch (err) {
          lastErr = err;
        }
      }
      if (!done) notes.push("الديكوريشن ما انطبق" + (lastErr ? ": " + errText(lastErr) : ""));
    }

    return notes;
  };

  // ===== المفاتيح =====
  var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  var b64enc = function (str) {
    var enc = encodeURIComponent(str), bytes = [], i;
    for (i = 0; i < enc.length; i++) {
      if (enc[i] === "%") { bytes.push(parseInt(enc.substr(i + 1, 2), 16)); i += 2; }
      else bytes.push(enc.charCodeAt(i));
    }
    var out = "";
    for (var j = 0; j < bytes.length; j += 3) {
      var a = bytes[j], b = bytes[j + 1], c = bytes[j + 2];
      out += B64[a >> 2] + B64[((a & 3) << 4) | ((b || 0) >> 4)] +
        (b === undefined ? "=" : B64[((b & 15) << 2) | ((c || 0) >> 6)]) +
        (c === undefined ? "=" : B64[c & 63]);
    }
    return out;
  };
  var b64dec = function (str) {
    str = str.replace(/[^A-Za-z0-9+\/]/g, "");
    var bytes = [], buf = 0, bits = 0;
    for (var i = 0; i < str.length; i++) {
      buf = (buf << 6) | B64.indexOf(str[i]); bits += 6;
      if (bits >= 8) { bits -= 8; bytes.push((buf >> bits) & 255); buf &= (1 << bits) - 1; }
    }
    var out = "";
    for (var k = 0; k < bytes.length; k++) out += "%" + ("0" + bytes[k].toString(16)).slice(-2);
    return decodeURIComponent(out);
  };

  var KEY_PREFIX = "PP1:";

  var makeKey = function (name) {
    var profiles = getState().profiles;
    var names = name ? [name] : Object.keys(profiles);
    if (!names.length) throw new Error("ما عندك بروفايلات محفوظة");
    var pack = {}, noImg = 0;
    names.forEach(function (n) {
      var d = profiles[n];
      if (!d) throw new Error("ما لقيت بروفايل " + n);
      var o = {};
      Object.keys(d).forEach(function (k) {
        if (k === "avatar" || k === "banner") return;
        var v = d[k];
        if (v === null || v === undefined || v === "" || (Array.isArray(v) && !v.length)) return;
        o[k] = v;
      });
      if ((d.avatar && !d.avatarUrl) || (d.banner && !d.bannerUrl)) noImg++;
      pack[n] = o;
    });
    return { key: KEY_PREFIX + b64enc(JSON.stringify({ v: 1, p: pack })), count: names.length, noImg: noImg };
  };

  var importKey = async function (key) {
    key = String(key || "").trim();
    if (key.indexOf(KEY_PREFIX) !== 0) throw new Error("المفتاح غير صحيح (لازم يبدأ بـ PP1:)");
    var obj;
    try { obj = JSON.parse(b64dec(key.slice(KEY_PREFIX.length))); }
    catch (_) { throw new Error("المفتاح تالف أو ناقص، انسخه كامل"); }
    if (!obj || !obj.p || typeof obj.p !== "object") throw new Error("المفتاح فاضي");
    var profiles = Object.assign({}, getState().profiles);
    var names = Object.keys(obj.p), added = [], notes = [];
    for (var i = 0; i < names.length; i++) {
      var n = names[i];
      var d = Object.assign({}, obj.p[n]);
      var finalName = n, c = 2;
      while (profiles[finalName]) { finalName = n + " (" + c + ")"; c++; }
      try { if (d.avatarUrl) d.avatar = await toDataURI(d.avatarUrl); }
      catch (_) { notes.push(finalName + ": تعذّر تحميل الأفتار"); }
      try { if (d.bannerUrl) d.banner = await toDataURI(d.bannerUrl); }
      catch (_) { notes.push(finalName + ": تعذّر تحميل البنر"); }
      profiles[finalName] = d;
      added.push(finalName);
    }
    setState({ profiles: profiles });
    return "تم أخذ " + added.length + " بروفايل ✅\n" + added.join("، ") + (notes.length ? "\n" + notes.join("\n") : "");
  };

  var copyText = function (t) {
    return safe(function () { V.externals.ReactNativeClipboard.Clipboard.setString(t); return true; }, false);
  };

  // ===== العمليات =====
  var requireGuild = function () {
    var g = currentGuildId();
    if (!g) throw new Error("ادخل سيرفر أول (افتح أي سيرفر ثم ارجع للإعدادات)");
    return g;
  };

  var saveCurrent = async function (name) {
    var guildId = requireGuild();
    var meId = me().id;
    var res = await fetchProfile(meId, guildId);
    var out = await buildData(res.body, meId, guildId, true);
    var profiles = Object.assign({}, getState().profiles);
    profiles[name] = out.data;
    setState({ profiles: profiles });
    return "تم حفظ " + name + " ✅ (أفتار: " + out.avatarSrc + ")";
  };

  var stealUser = async function (userId, name, applyNow) {
    var guildId = requireGuild();
    var cu = safe(function () { return Stores.UserStore.getUser(userId); });
    var finalName = name || (cu && cu.username) || userId;
    var res = await fetchProfile(userId, guildId);
    var out = await buildData(res.body, userId, guildId, false);
    var profiles = Object.assign({}, getState().profiles);
    profiles[finalName] = out.data;
    setState({ profiles: profiles });
    var text = "أخذت بروفايل " + finalName + " ✅";
    if (applyNow) {
      var notes = await applyProfile(out.data, guildId);
      text += "\nتم تطبيقه" + (notes.length ? "\n" + notes.join("\n") : " ✅");
    }
    return text;
  };

  var applyByName = async function (name) {
    var guildId = requireGuild();
    var d = getState().profiles[name];
    if (!d) throw new Error("ما لقيت بروفايل " + name);
    var notes = await applyProfile(d, guildId);
    return "تم تطبيق " + name + (notes.length ? "\n" + notes.join("\n") : " ✅");
  };

  var applyRandom = async function () {
    var names = Object.keys(getState().profiles);
    if (!names.length) throw new Error("ما عندك بروفايلات محفوظة");
    var name = names[Math.floor(Math.random() * names.length)];
    return "🎲 " + (await applyByName(name));
  };

  var renameProfile = function (oldName, newName, nick) {
    var s = getState();
    var profiles = Object.assign({}, s.profiles);
    var ns = Object.assign({}, s.ns);
    if (newName !== oldName) {
      if (profiles[newName]) throw new Error("فيه بروفايل بنفس الاسم");
      profiles[newName] = profiles[oldName];
      delete profiles[oldName];
      ns.names = (ns.names || []).map(function (n) { return n === oldName ? newName : n; });
    }
    profiles[newName] = Object.assign({}, profiles[newName], { nick: nick || null });
    setState({ profiles: profiles, ns: ns });
  };

  var deleteProfile = function (name) {
    var s = getState();
    var profiles = Object.assign({}, s.profiles);
    delete profiles[name];
    setState({
      profiles: profiles,
      ns: Object.assign({}, s.ns, { names: (s.ns.names || []).filter(function (n) { return n !== name; }) }),
    });
  };

  // ===== شاشة الإعدادات =====
  function SettingsComponent(props) {
    var U0;
    try { U0 = ui(); } catch (err) { return null; }
    var need = ["Stack", "TableRowGroup", "TableRow", "TableSwitchRow", "TextInput", "Button"];
    var miss = need.filter(function (n) { return !U0.D[n]; });
    ["View", "Text", "ScrollView"].forEach(function (n) { if (!U0.RN[n]) miss.push("RN." + n); });
    if (miss.length) {
      if (!U0.RN.Text) return null;
      return U0.R.createElement(U0.RN.Text, { style: { color: "#ffffff", padding: 16 } },
        "Per Profile: مكونات ناقصة: " + miss.join(", ") + "\nمفاتيح design: " + Object.keys(U0.D).slice(0, 40).join(", "));
    }
    return U0.R.createElement(SettingsInner, props);
  }

  function SettingsInner(props) {
    var U = ui();
    var R = U.R, RN = U.RN, D = U.D;
    var h = R.createElement;
    var storage = props.api.jsonStorage;
    var st = Object.assign({}, DEFAULTS, storage.use());
    st.profiles = st.profiles || {};
    st.ns = Object.assign({}, DEFAULTS.ns, st.ns || {});
    store = storage;
    mirror = st;

    var nameS = R.useState(""); var name = nameS[0], setName = nameS[1];
    var userS = R.useState(""); var userId = userS[0], setUserId = userS[1];
    var logS = R.useState(""); var log = logS[0], setLog = logS[1];
    var busyS = R.useState(false); var busy = busyS[0], setBusy = busyS[1];
    var editS = R.useState(null); var editing = editS[0], setEditing = editS[1];
    var enS = R.useState(""); var editName = enS[0], setEditName = enS[1];
    var ekS = R.useState(""); var editNick = ekS[0], setEditNick = ekS[1];
    var delS = R.useState(null); var confirmDel = delS[0], setConfirmDel = delS[1];
    var tkS = R.useState(0); var setTick = tkS[1];
    var knS = R.useState(""); var keyName = knS[0], setKeyName = knS[1];
    var koS = R.useState(""); var keyOut = koS[0], setKeyOut = koS[1];
    var kiS = R.useState(""); var keyIn = kiS[0], setKeyIn = kiS[1];

    var run = async function (fn) {
      if (busy) return;
      setBusy(true);
      try {
        var t = await fn();
        if (t) { setLog(String(t)); toast(String(t).split("\n")[0]); }
      } catch (err) {
        var m = "خطأ: " + ((err && err.message) || errText(err));
        setLog(m);
        toast(m);
      } finally {
        setBusy(false);
      }
    };

    var names = Object.keys(st.profiles);
    var Btn = function (key, text, onPress) {
      return h(D.Button, { key: key, text: text, size: "sm", onPress: onPress });
    };

    var body = h(D.Stack, { spacing: 24 }, [
      log ? h(D.TableRowGroup, { key: "log", title: "آخر نتيجة" }, h(D.TableRow, { label: log })) : null,

      h(D.TableRowGroup, { key: "cmd", title: "حالة أوامر /" }, [
        h(D.TableRow, { key: "cs", label: cmdStatus, subLabel: diag() }),
      ]),
      h(D.Button, {
        key: "cmdRetry",
        text: "إعادة تسجيل الأوامر",
        onPress: function () { if (retryCommands) retryCommands(); setTick(function (x) { return x + 1; }); },
      }),

      h(D.TableRowGroup, { key: "save", title: "حفظ" }, [
        h(D.TextInput, { key: "n", label: "اسم البروفايل", placeholder: "مثلاً: رسمي", value: name, onChange: setName, isClearable: true }),
      ]),
      h(D.Button, {
        key: "saveBtn",
        text: busy ? "جاري التنفيذ..." : "حفظ بروفايل السيرفر الحالي",
        onPress: function () {
          var n = name.trim();
          if (!n) return toast("اكتب اسم البروفايل");
          run(async function () { var t = await saveCurrent(n); setName(""); return t; });
        },
      }),

      h(D.TextInput, { key: "u", label: "أخذ بروفايل شخص (ID)", placeholder: "User ID", value: userId, onChange: setUserId, isClearable: true }),
      h(D.Button, {
        key: "stealBtn",
        text: "خذ بروفايله",
        onPress: function () {
          var id = userId.trim();
          if (!id) return toast("اكتب ID الشخص");
          run(async function () { var t = await stealUser(id, name.trim() || null, false); setUserId(""); return t; });
        },
      }),

      h(D.Button, { key: "rnd", text: "طبّق بروفايل عشوائي", onPress: function () { run(applyRandom); } }),

      h(D.TableRowGroup, { key: "keysT", title: "المفاتيح (مشاركة البروفايلات)" }, [
        h(D.TableRow, { key: "kx", label: "شارك بروفايلاتك بمفتاح", subLabel: "الصور تنزل من روابط ديسكورد عند الشخص اللي يدخل المفتاح" }),
      ]),
      h(D.TextInput, { key: "kn", label: "اسم البروفايل (فاضي = كل بروفايلاتك)", value: keyName, onChange: setKeyName, isClearable: true }),
      h(D.Button, {
        key: "kTake",
        text: "take key — خذ المفتاح",
        onPress: function () {
          try {
            var r = makeKey(keyName.trim() || null);
            setKeyOut(r.key);
            var m = "المفتاح جاهز (" + r.count + " بروفايل)" + (copyText(r.key) ? " واننسخ للحافظة" : "") +
              (r.noImg ? "\n⚠️ " + r.noImg + " بروفايل بدون صور (احفظه من جديد)" : "");
            setLog(m); toast(m.split("\n")[0]);
          } catch (err) { toast(err.message); }
        },
      }),
      keyOut ? h(D.TextInput, { key: "ko", label: "المفتاح (انسخه وأرسله)", value: keyOut, onChange: function () {} }) : null,
      h(D.TextInput, { key: "ki", label: "Insert the key — الصق المفتاح هنا", placeholder: "PP1:...", value: keyIn, onChange: setKeyIn, isClearable: true }),
      h(D.Button, {
        key: "kIns",
        text: "Insert the key",
        onPress: function () {
          var k = keyIn.trim();
          if (!k) return toast("الصق المفتاح أول");
          run(async function () { var t = await importKey(k); setKeyIn(""); return t; });
        },
      }),

      editing && st.profiles[editing]
        ? h(D.TableRowGroup, { key: "edit", title: "تعديل: " + editing }, [
            h(D.TextInput, { key: "en", label: "اسم البروفايل المحفوظ", value: editName, onChange: setEditName }),
            h(D.TextInput, { key: "ek", label: "الاسم المعروض في السيرفر (فاضي = ما يتغير)", value: editNick, onChange: setEditNick }),
            h(RN.View, { key: "eb", style: { flexDirection: "row", padding: 12 } }, [
              Btn("es", "حفظ", function () {
                try {
                  var nn = editName.trim();
                  if (!nn) return toast("الاسم فاضي");
                  renameProfile(editing, nn, editNick.trim());
                  setEditing(null);
                  toast("تم حفظ التعديل ✅");
                } catch (err) { toast(err.message); }
              }),
              Btn("ec", "إلغاء", function () { setEditing(null); }),
            ]),
          ])
        : null,

      h(D.TableRowGroup, { key: "list", title: "بروفايلاتك (" + names.length + ")" },
        names.length
          ? names.map(function (n) {
              return h(D.TableRow, {
                key: "p-" + n,
                label: n,
                subLabel: summary(st.profiles[n]),
                trailing: h(RN.View, { style: { flexDirection: "row" } }, [
                  Btn("a", "تطبيق", function () { run(function () { return applyByName(n); }); }),
                  Btn("e", "تعديل", function () {
                    setEditing(n); setEditName(n); setEditNick(st.profiles[n].nick || ""); setConfirmDel(null);
                  }),
                  Btn("d", confirmDel === n ? "تأكيد" : "حذف", function () {
                    if (confirmDel !== n) return setConfirmDel(n);
                    deleteProfile(n); setConfirmDel(null);
                    if (editing === n) setEditing(null);
                  }),
                ]),
              });
            })
          : h(D.TableRow, { label: "ما عندك بروفايلات محفوظة" })
      ),

      h(D.TableRowGroup, { key: "ns", title: "السيرفرات الجديدة" },
        [h(D.TableSwitchRow, {
          key: "nsOn",
          label: "تطبيق بروفايل تلقائياً عند دخول سيرفر جديد",
          subLabel: "ما حددت شي = يختار من كل بروفايلاتك",
          value: !!st.ns.enabled,
          onValueChange: function (v) { setState({ ns: Object.assign({}, st.ns, { enabled: v }) }); },
        })].concat(
          names.map(function (n) {
            return h(D.TableSwitchRow, {
              key: "ns-" + n,
              label: n,
              value: st.ns.names.indexOf(n) >= 0,
              onValueChange: function (v) {
                var arr = st.ns.names.filter(function (x) { return x !== n; });
                if (v) arr.push(n);
                setState({ ns: Object.assign({}, st.ns, { names: arr }) });
              },
            });
          })
        )
      ),
    ]);

    var content = h(RN.ScrollView, { contentContainerStyle: { paddingBottom: 40 } }, body);
    return U.Page ? h(U.Page, null, content) : content;
  }

  // ===== السيرفر الجديد =====
  var knownGuilds = null;
  var onGuildCreate = function (ev) {
    try {
      var g = ev && ev.guild;
      var id = g && g.id;
      if (!id || !knownGuilds || knownGuilds.has(id)) return;
      knownGuilds.add(id);
      if (g.joined_at && Date.now() - new Date(g.joined_at).getTime() > 5 * 60 * 1000) return;
      var s = getState();
      if (!s.ns.enabled) return;
      var pool = (s.ns.names || []).filter(function (n) { return s.profiles[n]; });
      if (!pool.length) pool = Object.keys(s.profiles);
      if (!pool.length) return;
      var pn = pool[Math.floor(Math.random() * pool.length)];
      setTimeout(async function () {
        try {
          var notes = await applyProfile(s.profiles[pn], id);
          toast("سيرفر جديد: طبّقت " + pn + (notes.length ? " (مع ملاحظات)" : " ✅"));
        } catch (_) {
          toast("فشل تطبيق بروفايل السيرفر الجديد");
        }
      }, 3000);
    } catch (_) {}
  };


  // ===== أوامر slash =====
  var argOf = function (args, n) {
    var a = args && args.find ? args.find(function (x) { return x.name === n; }) : null;
    return a ? a.value : undefined;
  };

  var opt = function (name, desc, type, required, choices) {
    var o = {
      name: name, displayName: name, serverLocalizedName: name, untranslatedName: name,
      description: desc, displayDescription: desc, serverLocalizedDescription: desc, untranslatedDescription: desc,
      type: type, required: !!required,
    };
    if (choices) {
      o.choices = choices.map(function (c) {
        var v = typeof c === "string" ? c : c.value;
        var l = typeof c === "string" ? c : c.label;
        return { name: v, displayName: l, serverLocalizedName: l, untranslatedName: l, label: l, value: v };
      });
    }
    return o;
  };

  var listText = function () {
    var names = Object.keys(getState().profiles);
    if (!names.length) return "ما عندك بروفايلات محفوظة.";
    return "بروفايلاتك (" + names.length + "):\n" + names.map(function (n, i) {
      return (i + 1) + ". **" + n + "** — " + summary(getState().profiles[n]);
    }).join("\n");
  };

  var COMMANDS = [
    ["save_pr", "احفظ بروفايل السيرفر الحالي", [opt("name", "اسم البروفايل", 3, true)],
      function (a) { return saveCurrent(argOf(a, "name")); }],
    ["set_pr", "طبّق بروفايل محفوظ (بدون اسم = يعرض القائمة)", [opt("name", "اسم البروفايل", 3, false)],
      function (a) { var n = argOf(a, "name"); return n ? applyByName(n) : listText(); }],
    ["show_per", "اعرض بروفايلاتك المحفوظة", [],
      function () { return listText(); }],
    ["edit_per", "عدّل بروفايل محفوظ (الاسم المحفوظ أو الاسم المعروض)",
      [opt("name", "اسم البروفايل", 3, true), opt("new_name", "اسم البروفايل الجديد", 3, false), opt("display_name", "الاسم المعروض (اكتب - للمسح)", 3, false)],
      function (a) {
        var n = argOf(a, "name"), nn = argOf(a, "new_name"), dn = argOf(a, "display_name");
        var d = getState().profiles[n];
        if (!d) throw new Error("ما لقيت بروفايل " + n);
        var nick = d.nick;
        if (dn != null) { var v = String(dn).trim(); nick = v === "" || v === "-" ? null : v; }
        var finalName = nn && String(nn).trim() ? String(nn).trim() : n;
        renameProfile(n, finalName, nick);
        return "تم تعديل **" + finalName + "** ✅";
      }],
    ["rename_pr", "غيّر اسم بروفايل محفوظ", [opt("name", "الاسم الحالي", 3, true), opt("new_name", "الاسم الجديد", 3, true)],
      function (a) {
        var n = argOf(a, "name"), nn = String(argOf(a, "new_name") || "").trim();
        var d = getState().profiles[n];
        if (!d) throw new Error("ما لقيت بروفايل " + n);
        if (!nn) throw new Error("اكتب الاسم الجديد");
        renameProfile(n, nn, d.nick);
        return "تم تغيير الاسم من **" + n + "** إلى **" + nn + "** ✅";
      }],
    ["delete_pr", "احذف بروفايل محفوظ", [opt("name", "اسم البروفايل", 3, true)],
      function (a) {
        var n = argOf(a, "name");
        if (!getState().profiles[n]) throw new Error("ما لقيت بروفايل " + n);
        deleteProfile(n);
        return "تم حذف **" + n + "** 🗑️";
      }],
    ["stole_per", "خذ بروفايل شخص ثاني",
      [opt("user", "الشخص", 6, true), opt("name", "اسم تحفظه به (اختياري)", 3, false), opt("apply", "طبّقه مباشرة", 5, false)],
      function (a) { return stealUser(argOf(a, "user"), argOf(a, "name") || null, !!argOf(a, "apply")); }],
    ["key_per", "شارك بروفايلاتك بمفتاح: take key لأخذ مفتاح، Insert the key لإدخال مفتاح",
      [opt("action", "اختر العملية", 3, true, [{ value: "take", label: "take key" }, { value: "insert", label: "Insert the key" }]),
       opt("key", "المفتاح (مع Insert the key)", 3, false),
       opt("name", "اسم بروفايل واحد (مع take key، فاضي = كل بروفايلاتك)", 3, false)],
      function (a) {
        if (argOf(a, "action") === "insert") return importKey(argOf(a, "key"));
        var r = makeKey(argOf(a, "name") || null);
        var copied = copyText(r.key);
        return "مفتاح " + r.count + " بروفايل" + (copied ? " (اننسخ للحافظة)" : "") + ":\n`" + r.key + "`" +
          (r.noImg ? "\n⚠️ " + r.noImg + " بروفايل محفوظ قبل التحديث، صوره ما تنتقل. احفظه من جديد." : "");
      }],
    ["random_per", "طبّق بروفايل عشوائي من بروفايلاتك", [],
      function () { return applyRandom(); }],
    ["newserver_per", "اختيار بروفايل تلقائياً عند دخول سيرفر جديد (الاختيار من الإعدادات)",
      [opt("mode", "on للتشغيل، off للإيقاف", 3, true, ["on", "off"])],
      function (a) {
        var on = argOf(a, "mode") === "on";
        setState({ ns: Object.assign({}, getState().ns, { enabled: on }) });
        return on ? "تم تشغيل البروفايل التلقائي للسيرفرات الجديدة ✅" : "تم إيقاف البروفايل التلقائي ⏹️";
      }],
  ];

  var cmdStatus = "⏳ لم يبدأ التسجيل";
  var retryCommands = null;
  var diag = function () {
    var pk = safe(function () { return Object.keys(V.plugins || {}).slice(0, 25).join(", "); }, "");
    var gk = safe(function () {
      return Object.keys(globalThis).filter(function (k) { return k.indexOf("__c") === 0 || /util/i.test(k); }).slice(0, 15).join(", ");
    }, "");
    var uk = safe(function () { return Object.keys(V.plugins.utils || {}).slice(0, 30).join(", "); }, "");
    var ck = safe(function () { return Object.keys(V.plugins.constants || {}).slice(0, 30).join(", "); }, "");
    var fk = safe(function () { var m = find("registerCommand"); return m ? "found" : "none"; }, "err");
    return "valenced.plugins: " + (pk || "—") + "\nutils: " + (uk || "—") + "\nconstants: " + (ck || "—") +
      "\nglobal: " + (gk || "—") + "\nfind(registerCommand): " + fk;
  };

  var enumValue = function (name, key, fallback) {
    try {
      var m = find(name);
      var v = m && m[name] && m[name][key];
      return v != null ? v : fallback;
    } catch (_) {
      return fallback;
    }
  };

  // رسالة محلية (ما تنرسل للقناة)
  var sendLocal = function (ctx, text) {
    var ch = ctx && ctx.channel && ctx.channel.id;
    var bm = find("sendBotMessage");
    if (bm && bm.sendBotMessage && ch) {
      try { bm.sendBotMessage(ch, text); return; } catch (_) {}
    }
    toast(String(text).split("\n")[0]);
  };

  var registerCommands = function (api) {
    var installed = false;

    var mkCmd = function (c, i) {
      var desc = c[1];
      return {
        id: String(-81000 - i),
        name: c[0], displayName: c[0], serverLocalizedName: c[0], untranslatedName: c[0],
        description: desc, displayDescription: desc, serverLocalizedDescription: desc, untranslatedDescription: desc,
        type: 1,
        inputType: enumValue("ApplicationCommandInputType", "BUILT_IN_TEXT", 1),
        applicationId: "-1",
        options: c[2],
        predicate: function () { return true; },
        execute: async function (args, ctx) {
          try {
            sendLocal(ctx, String(await c[3](args, ctx)));
          } catch (err) {
            sendLocal(ctx, "خطأ: " + ((err && err.message) || errText(err)));
          }
        },
      };
    };

    var install = function () {
      if (installed) return;
      installed = true;
      var cmds = COMMANDS.map(mkCmd);
      cmdStatus = "⏳ أدوّر على getBuiltInCommands";
      api.cleanup(F.getModules(F.filters.withProps("getBuiltInCommands"), function (mod) {
        api.cleanup(V.patcher.instead(mod, "getBuiltInCommands", function (args, orig) {
          var result = orig.apply(this, args);
          try {
            var types = args && args[0];
            var wantsChat = Array.isArray(types) ? types.indexOf(1) >= 0 : types == null || types === 1;
            if (!wantsChat || !Array.isArray(result)) return result;
            if (result.some(function (x) { return x && String(x.id) === cmds[0].id; })) return result;
            return result.concat(cmds);
          } catch (_) {
            return result;
          }
        }));
        cmdStatus = "✅ الأوامر مسجّلة (" + cmds.length + ") عبر getBuiltInCommands";
      }));
    };

    install();
    retryCommands = install;
  };

  return (
    (e.default = plugin({
      jsonStorage: { load: true, default: DEFAULTS },
      start: function (ctx) {
        store = ctx.jsonStorage;
        knownGuilds = new Set(Object.keys(safe(function () { return Stores.GuildStore.getGuilds(); }, {}) || {}));
        registerCommands(ctx);
        if (Dispatcher && Dispatcher.subscribe) {
          Dispatcher.subscribe("GUILD_CREATE", onGuildCreate);
          ctx.cleanup(function () { safe(function () { Dispatcher.unsubscribe("GUILD_CREATE", onGuildCreate); }); });
        }
      },
      SettingsComponent: SettingsComponent,
    })),
    e
  );
})({});
