(function (e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });

  var V = valenced;
  var safe = function (f, d) {
    try {
      var r = f();
      return r === undefined ? d : r;
    } catch (_) {
      return d;
    }
  };
  var norm = function (m) {
    return m && m.default && typeof m.default !== "string" && !m.createElement && !m.View ? m.default : m;
  };

  var F = V.modules.finders;
  var find = function () {
    var p = Array.prototype.slice.call(arguments);
    return safe(function () {
      return F.lookupModule(F.filters.withProps.apply(null, p))[0];
    });
  };

  // ===== الوحدات =====
  var Stores = new Proxy({}, { get: function (_, k) { return V.discord.flux.Stores[k]; } });
  var Dispatcher = safe(function () { return V.discord.common.flux.Dispatcher; });
  var Toast = safe(function () { return V.discord.actions.ToastActionCreators; });
  var httpCache = null;
  var getHTTP = function () {
    if (httpCache) return httpCache;
    var m = find("HTTP", "post");
    var h = (m && m.HTTP) || find("getAPIBaseURL", "get", "patch");
    if (!h || !h.get) throw new Error("HTTP module not found");
    httpCache = h;
    return h;
  };
  var HTTP = {
    get: function (o) { return getHTTP().get(o); },
    patch: function (o) { return getHTTP().patch(o); },
  };

  var uiCache = null;
  var ui = function () {
    if (uiCache) return uiCache;
    var R = norm(safe(function () { return V.externals.React; })) || find("createElement", "useState");
    var RN = norm(safe(function () { return V.externals.ReactNative; })) || find("View", "Text", "ScrollView");
    var dm = safe(function () { return V.discord.design; });
    var D = dm && (dm.Design || dm);
    var Page = norm(safe(function () { return V.components.Page; }));
    var okType = function (x) { return typeof x === "function" || (x && typeof x === "object" && x.$$typeof); };
    if (!okType(Page)) Page = null;
    if (!R) throw new Error("React not found");
    if (!RN) throw new Error("ReactNative not found");
    if (!D) throw new Error("Design components not found");
    uiCache = { R: R, RN: RN, D: D, Page: Page };
    return uiCache;
  };

  // ===== التخزين =====
  var DEFAULTS = { profiles: {}, ns: { enabled: false, names: [] } };
  var store = null;
  var mirror = DEFAULTS;

  var recentPatch = null;
  var getState = function () {
    var s = safe(function () { return store && store.cache ? store.cache : undefined; });
    s = s || safe(function () { return store && typeof store.get === "function" ? store.get() : undefined; });
    s = s || mirror;
    if (recentPatch && Date.now() - recentPatch.t < 3000) s = Object.assign({}, s, recentPatch.patch);
    return Object.assign({}, DEFAULTS, s, {
      profiles: (s && s.profiles) || {},
      ns: Object.assign({}, DEFAULTS.ns, (s && s.ns) || {}),
    });
  };
  var setState = function (patch) {
    mirror = Object.assign({}, getState(), patch);
    recentPatch = { t: Date.now(), patch: patch };
    if (store && typeof store.set === "function") store.set(patch);
  };

  // ===== أدوات =====
  var toast = function (t) {
    safe(function () {
      Toast.open("per-profile", { text: String(t).slice(0, 120) });
    });
  };

  var errText = function (err) {
    try {
      var b = (err && err.body) || err;
      return (((err && err.status) || "") + " " + (JSON.stringify(b) || (err && err.message) || err)).slice(0, 400);
    } catch (_) {
      return String(err);
    }
  };

  var clean = function (o) {
    var out = {};
    Object.keys(o).forEach(function (k) {
      if (o[k] !== null && o[k] !== undefined) out[k] = o[k];
    });
    return out;
  };

  var ext = function (hash) { return String(hash).indexOf("a_") === 0 ? "gif" : "png"; };

  var toDataURI = async function (url) {
    var blob = await (await fetch(url)).blob();
    return await new Promise(function (res, rej) {
      var r = new FileReader();
      r.onloadend = function () { res(r.result); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  };

  var currentGuildId = function () {
    return safe(function () { return Stores.SelectedGuildStore.getGuildId(); });
  };
  var me = function () { return Stores.UserStore.getCurrentUser(); };

  var fetchProfile = function (userId, guildId) {
    return HTTP.get({
      url: "/users/" + userId + "/profile?with_mutual_guilds=false&guild_id=" + guildId,
    });
  };

  // ===== قراءة البيانات =====
  var effId = function (x) {
    return x ? (x.sku_id != null ? x.sku_id : x.skuId != null ? x.skuId : x.id != null ? x.id : null) : null;
  };

  var readEffect = function (body) {
    var p = body.guild_member_profile || {};
    var up = body.user_profile || {};
    var r = effId(p.profile_effect);
    if (r == null) r = p.profile_effect_id;
    if (r == null) r = effId(up.profile_effect);
    if (r == null) r = up.profile_effect_id;
    return r == null ? null : r;
  };

  var readGuildDecoration = function (body) {
    var src = body.guild_member && body.guild_member.avatar_decoration_data;
    if (!src || !src.asset) return null;
    return { asset: src.asset, sku_id: src.sku_id != null ? src.sku_id : src.skuId != null ? src.skuId : null };
  };

  var readNameStyle = function (body) {
    var pick = function (s) {
      if (!s || typeof s !== "object") return null;
      var has = s.font_id != null || s.effect_id != null || (Array.isArray(s.colors) && s.colors.length > 0);
      return has ? s : null;
    };
    return pick(body.guild_member && body.guild_member.display_name_styles) ||
      pick(body.user && body.user.display_name_styles) || null;
  };

  var sameStyle = function (a, b) {
    var n = function (s) {
      return JSON.stringify([s && s.font_id != null ? s.font_id : null, s && s.effect_id != null ? s.effect_id : null, (s && s.colors) || []]);
    };
    return n(a) === n(b);
  };

  var buildData = async function (body, userId, guildId, withNick) {
    var p = body.guild_member_profile || {};
    var m = body.guild_member || {};
    var u = body.user || {};
    var up = body.user_profile || {};

    var avatarUrl = null;
    var avatarSrc = "ما فيه";
    var cu = safe(function () { return Stores.UserStore.getUser(userId); });
    var avatarHash = u.avatar || (cu && cu.avatar);
    if (m.avatar) {
      avatarUrl = "https://cdn.discordapp.com/guilds/" + guildId + "/users/" + userId + "/avatars/" + m.avatar + "." + ext(m.avatar) + "?size=1024";
      avatarSrc = "خاص بالسيرفر";
    } else if (avatarHash) {
      avatarUrl = "https://cdn.discordapp.com/avatars/" + userId + "/" + avatarHash + "." + ext(avatarHash) + "?size=1024";
      avatarSrc = "عام";
    }

    var bannerUrl = null;
    if (p.banner) {
      bannerUrl = "https://cdn.discordapp.com/guilds/" + guildId + "/users/" + userId + "/banners/" + p.banner + "." + ext(p.banner) + "?size=1024";
    } else if (u.banner || up.banner) {
      var bh = u.banner || up.banner;
      bannerUrl = "https://cdn.discordapp.com/banners/" + userId + "/" + bh + "." + ext(bh) + "?size=1024";
    }

    var pick = function (a, b) { return a != null ? a : b; };
    var data = {
      bio: pick(p.bio, pick(up.bio, "")),
      pronouns: pick(p.pronouns, pick(up.pronouns, "")),
      accent_color: pick(p.accent_color, pick(up.accent_color, pick(u.accent_color, null))),
      theme_colors: pick(p.theme_colors, pick(up.theme_colors, null)),
      profile_effect_id: readEffect(body),
      avatar_decoration: readGuildDecoration(body),
      display_name_styles: readNameStyle(body),
      nick: withNick ? (m.nick != null ? m.nick : null) : null,
      avatarUrl: avatarUrl,
      bannerUrl: bannerUrl,
      avatar: avatarUrl ? await toDataURI(avatarUrl) : null,
      banner: bannerUrl ? await toDataURI(bannerUrl) : null,
    };
    return { data: data, avatarSrc: avatarSrc };
  };

  var summary = function (d) {
    return [
      d.avatar ? "أفتار" : null,
      d.banner ? "بنر" : null,
      d.profile_effect_id ? "افكت" : null,
      d.avatar_decoration ? "ديكوريشن" : null,
      d.display_name_styles ? "ستايل اسم" : null,
      d.bio ? "بايو" : null,
      d.nick ? "اسم: " + d.nick : null,
    ].filter(Boolean).join(" • ") || "فاضي";
  };

  // ===== التطبيق =====
  var applyProfile = async function (d, guildId) {
    var notes = [];
    var meId = me().id;

    if (d.nick) {
      try {
        await HTTP.patch({ url: "/guilds/" + guildId + "/members/@me", body: { nick: d.nick } });
      } catch (err) {
        if (!(err && err.body && err.body.code === 50013)) notes.push("النك نيم: " + errText(err));
      }
    }

    if (d.avatar) {
      try {
        await HTTP.patch({ url: "/guilds/" + guildId + "/members/@me", body: { avatar: d.avatar } });
      } catch (err) {
        notes.push(
          JSON.stringify((err && err.body) || "").indexOf("AVATAR_RATE_LIMIT") >= 0
            ? "الأفتار: ديسكورد يحدّ التغيير، جرّب بعد 10-15 دقيقة"
            : "الأفتار: " + errText(err)
        );
      }
    }

    if (d.display_name_styles) {
      var st = d.display_name_styles;
      try {
        await HTTP.patch({
          url: "/guilds/" + guildId + "/members/@me",
          body: clean({
            display_name_font_id: st.font_id,
            display_name_effect_id: st.effect_id,
            display_name_colors: st.colors,
          }),
        });
        var r1 = await fetchProfile(meId, guildId);
        if (!sameStyle(readNameStyle(r1.body), st)) notes.push("ستايل الاسم: ما تغيّر (غالباً ما تملك الخط أو التأثير)");
      } catch (err) {
        notes.push("ستايل الاسم: " + errText(err));
      }
    }

    try {
      await HTTP.patch({
        url: "/guilds/" + guildId + "/profile/@me",
        body: clean({
          bio: d.bio,
          pronouns: d.pronouns,
          banner: d.banner,
          accent_color: d.accent_color,
          theme_colors: d.theme_colors,
        }),
      });
    } catch (err) {
      notes.push("البنر/الألوان/البايو: " + errText(err));
    }

    if (d.profile_effect_id) {
      try {
        await HTTP.patch({
          url: "/guilds/" + guildId + "/profile/@me",
          body: { collectibles_sku_ids: [String(d.profile_effect_id)] },
        });
        var r2 = await fetchProfile(meId, guildId);
        var got = readEffect(r2.body);
        if (String(got) !== String(d.profile_effect_id)) notes.push("الافكت: ما تغيّر (الحالي " + (got != null ? got : "ما فيه") + ")");
      } catch (err) {
        notes.push("الافكت: " + errText(err));
      }
    }

    if (d.avatar_decoration && d.avatar_decoration.asset) {
      var dec = d.avatar_decoration;
      var ids = [dec.sku_id, d.profile_effect_id].filter(Boolean).map(String);
      var attempts = [];
      if (dec.sku_id) attempts.push({ url: "/guilds/" + guildId + "/profile/@me", body: { collectibles_sku_ids: ids } });
      attempts.push(
        { url: "/guilds/" + guildId + "/members/@me", body: { avatar_decoration_id: dec.sku_id != null ? dec.sku_id : dec.asset, avatar_decoration_sku_id: dec.sku_id } },
        { url: "/guilds/" + guildId + "/members/@me", body: { avatar_decoration_data: { asset: dec.asset, sku_id: dec.sku_id } } },
        { url: "/guilds/" + guildId + "/profile/@me", body: { avatar_decoration_data: { asset: dec.asset, sku_id: dec.sku_id } } }
      );
      var done = false;
      var lastErr = null;
      for (var i = 0; i < attempts.length; i++) {
        try {
          await HTTP.patch({ url: attempts[i].url, body: clean(attempts[i].body) });
          var r3 = await fetchProfile(meId, guildId);
          var gd = readGuildDecoration(r3.body);
          if (gd && gd.asset === dec.asset) { done = true; break; }
        } catch (err) {
          lastErr = err;
        }
      }
      if (!done) notes.push("الديكوريشن ما انطبق" + (lastErr ? ": " + errText(lastErr) : ""));
    }

    return notes;
  };

  const PROFILES = function () { return getState().profiles; };
  const SAVE = function (n, d) {
    var p = Object.assign({}, getState().profiles);
    p[n] = d;
    setState({ profiles: p });
  };
  const copyText = function (t) {
    return safe(function () { V.externals.ReactNativeClipboard.Clipboard.setString(t); return true; }, false);
  };

  // ===== المفاتيح (مشاركة البروفايلات) =====
  // المفتاح = JSON مضغوط (LZW) ثم base64 ثم مقسوم لأجزاء كل جزء أقل من 2000 حرف
  const utf8Bytes = (str) => {
    const enc = encodeURIComponent(str);
    const out = [];
    for (let i = 0; i < enc.length; i++) {
      if (enc[i] === "%") {
        out.push(parseInt(enc.substr(i + 1, 2), 16));
        i += 2;
      } else out.push(enc.charCodeAt(i));
    }
    return out;
  };
  const bytesUtf8 = (bytes) => {
    let s = "";
    for (const b of bytes) s += "%" + ("0" + b.toString(16)).slice(-2);
    return decodeURIComponent(s);
  };
  const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const b64FromBytes = (bytes) => {
    let out = "";
    for (let j = 0; j < bytes.length; j += 3) {
      const a = bytes[j], b = bytes[j + 1], c = bytes[j + 2];
      out +=
        B64[a >> 2] +
        B64[((a & 3) << 4) | ((b || 0) >> 4)] +
        (b === undefined ? "=" : B64[((b & 15) << 2) | ((c || 0) >> 6)]) +
        (c === undefined ? "=" : B64[c & 63]);
    }
    return out;
  };
  const b64ToBytes = (str) => {
    str = str.replace(/[^A-Za-z0-9+\/]/g, "");
    const bytes = [];
    let buf = 0, bits = 0;
    for (let i = 0; i < str.length; i++) {
      buf = (buf << 6) | B64.indexOf(str[i]);
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        bytes.push((buf >> bits) & 255);
        buf &= (1 << bits) - 1;
      }
    }
    return bytes;
  };

  const lzwEnc = (bytes) => {
    const dict = new Map();
    let size = 256;
    let w = "";
    const out = [];
    const code = (s) => (s.length === 1 ? s.charCodeAt(0) : dict.get(s));
    for (const b of bytes) {
      const c = String.fromCharCode(b);
      const wc = w + c;
      if (wc.length === 1 || dict.has(wc)) w = wc;
      else {
        out.push(code(w));
        if (size < 4096) dict.set(wc, size++);
        w = c;
      }
    }
    if (w) out.push(code(w));
    return out;
  };
  const lzwDec = (codes) => {
    if (!codes.length) return [];
    const dict = [];
    for (let i = 0; i < 256; i++) dict[i] = String.fromCharCode(i);
    let size = 256;
    let w = dict[codes[0]];
    const out = [w];
    for (let i = 1; i < codes.length; i++) {
      const k = codes[i];
      let entry;
      if (dict[k] !== undefined) entry = dict[k];
      else if (k === size) entry = w + w[0];
      else throw new Error("bad lzw");
      out.push(entry);
      if (size < 4096) dict[size++] = w + entry[0];
      w = entry;
    }
    const s = out.join("");
    const bytes = [];
    for (let i = 0; i < s.length; i++) bytes.push(s.charCodeAt(i));
    return bytes;
  };
  const packCodes = (codes) => {
    const n = codes.length;
    const bytes = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    for (let i = 0; i < n; i += 2) {
      const a = codes[i];
      const b = i + 1 < n ? codes[i + 1] : 0;
      bytes.push(a >> 4, ((a & 15) << 4) | (b >> 8), b & 255);
    }
    return bytes;
  };
  const unpackCodes = (bytes) => {
    const n = (bytes[0] << 16) | (bytes[1] << 8) | bytes[2];
    const codes = [];
    for (let i = 3; i < bytes.length && codes.length < n; i += 3) {
      const x = bytes[i], y = bytes[i + 1] || 0, z = bytes[i + 2] || 0;
      codes.push((x << 4) | (y >> 4));
      if (codes.length < n) codes.push(((y & 15) << 8) | z);
    }
    return codes;
  };

  const shortUrl = (u) =>
    typeof u === "string" ? u.replace(/^https:\/\/cdn\.discordapp\.com\//, "").replace(/\?size=1024$/, "") : u;
  const longUrl = (u) =>
    typeof u === "string" && !/^https?:/.test(u) ? "https://cdn.discordapp.com/" + u + "?size=1024" : u;

  const PART_SIZE = 1850;

  const makeKey = (name) => {
    const all = PROFILES();
    const names = name ? [name] : Object.keys(all);
    if (!names.length) throw new Error("ما عندك بروفايلات محفوظة");
    const pack = {};
    let noImg = 0;
    for (const n of names) {
      const d = all[n];
      if (!d) throw new Error("ما لقيت بروفايل " + n);
      const o = {};
      for (const k of Object.keys(d)) {
        if (k === "avatar" || k === "banner") continue;
        const v = d[k];
        if (v === null || v === undefined || v === "" || (Array.isArray(v) && !v.length)) continue;
        o[k] = k === "avatarUrl" || k === "bannerUrl" ? shortUrl(v) : v;
      }
      if ((d.avatar && !d.avatarUrl) || (d.banner && !d.bannerUrl)) noImg++;
      pack[n] = o;
    }
    const payload = b64FromBytes(packCodes(lzwEnc(utf8Bytes(JSON.stringify({ v: 2, p: pack })))));
    const id = Math.random().toString(36).slice(2, 6);
    const total = Math.max(1, Math.ceil(payload.length / PART_SIZE));
    const parts = [];
    for (let i = 0; i < total; i++) {
      parts.push(`PP2.${id}.${i + 1}.${total}:` + payload.slice(i * PART_SIZE, (i + 1) * PART_SIZE));
    }
    return { parts, count: names.length, noImg };
  };

  const importObj = async (obj) => {
    if (!obj || !obj.p || typeof obj.p !== "object") throw new Error("المفتاح فاضي");
    const added = [];
    const notes = [];
    for (const n of Object.keys(obj.p)) {
      const d = { ...obj.p[n] };
      if (d.avatarUrl) d.avatarUrl = longUrl(d.avatarUrl);
      if (d.bannerUrl) d.bannerUrl = longUrl(d.bannerUrl);
      let finalName = n;
      let c = 2;
      while (PROFILES()[finalName]) finalName = `${n} (${c++})`;
      try {
        if (d.avatarUrl) d.avatar = await toDataURI(d.avatarUrl);
      } catch {
        notes.push(finalName + ": تعذّر تحميل الأفتار");
      }
      try {
        if (d.bannerUrl) d.banner = await toDataURI(d.bannerUrl);
      } catch {
        notes.push(finalName + ": تعذّر تحميل البنر");
      }
      SAVE(finalName, d);
      added.push(finalName);
    }
    return `تم أخذ ${added.length} بروفايل ✅\n${added.join("، ")}` + (notes.length ? "\n" + notes.join("\n") : "");
  };

  const pendingKeys = {};

  // يقبل جزء أو أكثر (مفصولة بمسافة أو سطر)، ويستورد لما تكتمل كل الأجزاء
  const feedKeys = async (input) => {
    const text = String(input || "");
    const re2 = /PP2\.([A-Za-z0-9]{3,8})\.(\d+)\.(\d+):((?:(?!PP2\.[A-Za-z0-9]{3,8}\.\d+\.\d+:)[A-Za-z0-9+\/=])+)/g;
    const lines = [];
    const touched = [];
    let found = false;
    let m;
    while ((m = re2.exec(text))) {
      found = true;
      const id = m[1];
      if (!pendingKeys[id]) pendingKeys[id] = { n: parseInt(m[3], 10), parts: {} };
      pendingKeys[id].parts[parseInt(m[2], 10)] = m[4];
      if (touched.indexOf(id) < 0) touched.push(id);
    }
    for (const id of touched) {
      const p = pendingKeys[id];
      const missing = [];
      for (let i = 1; i <= p.n; i++) if (!p.parts[i]) missing.push(i);
      if (missing.length) {
        lines.push(`استلمت ${p.n - missing.length} من ${p.n} أجزاء. ناقص: ${missing.join("، ")}\nأرسل الباقي بنفس الأمر (Insert the key).`);
        continue;
      }
      let payload = "";
      for (let i = 1; i <= p.n; i++) payload += p.parts[i];
      delete pendingKeys[id];
      let obj;
      try {
        obj = JSON.parse(bytesUtf8(lzwDec(unpackCodes(b64ToBytes(payload)))));
      } catch {
        lines.push("المفتاح تالف، تأكد إنك نسخت كل الأجزاء كاملة");
        continue;
      }
      lines.push(await importObj(obj));
    }
    const m1 = text.match(/PP1:([A-Za-z0-9+\/=]+)/);
    if (m1) {
      found = true;
      let obj;
      try {
        obj = JSON.parse(bytesUtf8(b64ToBytes(m1[1])));
      } catch {
        throw new Error("المفتاح القديم تالف أو ناقص");
      }
      lines.push(await importObj(obj));
    }
    if (!found) throw new Error("ما لقيت مفتاح صحيح في النص (لازم يبدأ بـ PP2.)");
    return lines.join("\n");
  };

  const keyTakeText = (r) =>
    `مفتاح ${r.count} بروفايل في ${r.parts.length} ${r.parts.length > 1 ? "أجزاء" : "جزء"}.` +
    (r.parts.length > 1
      ? "\nأرسل الأجزاء بالترتيب (كل جزء رسالة)، وللنسخ اضغط مطوّلاً على الرسالة."
      : "\nاننسخ للحافظة.") +
    (r.noImg ? `\n⚠️ ${r.noImg} بروفايل بدون روابط صور، احفظه من جديد عشان تنتقل صوره.` : "");

  // ===== العمليات =====
  var requireGuild = function () {
    var g = currentGuildId();
    if (!g) throw new Error("ادخل سيرفر أول (افتح أي سيرفر ثم ارجع للإعدادات)");
    return g;
  };

  var saveCurrent = async function (name) {
    var guildId = requireGuild();
    var meId = me().id;
    var res = await fetchProfile(meId, guildId);
    var out = await buildData(res.body, meId, guildId, true);
    var profiles = Object.assign({}, getState().profiles);
    profiles[name] = out.data;
    setState({ profiles: profiles });
    return "تم حفظ " + name + " ✅ (أفتار: " + out.avatarSrc + ")";
  };

  var stealUser = async function (userId, name, applyNow) {
    var guildId = requireGuild();
    var cu = safe(function () { return Stores.UserStore.getUser(userId); });
    var finalName = name || (cu && cu.username) || userId;
    var res = await fetchProfile(userId, guildId);
    var out = await buildData(res.body, userId, guildId, false);
    var profiles = Object.assign({}, getState().profiles);
    profiles[finalName] = out.data;
    setState({ profiles: profiles });
    var text = "أخذت بروفايل " + finalName + " ✅";
    if (applyNow) {
      var notes = await applyProfile(out.data, guildId);
      text += "\nتم تطبيقه" + (notes.length ? "\n" + notes.join("\n") : " ✅");
    }
    return text;
  };

  var applyByName = async function (name) {
    var guildId = requireGuild();
    var d = getState().profiles[name];
    if (!d) throw new Error("ما لقيت بروفايل " + name);
    var notes = await applyProfile(d, guildId);
    return "تم تطبيق " + name + (notes.length ? "\n" + notes.join("\n") : " ✅");
  };

  var applyRandom = async function () {
    var names = Object.keys(getState().profiles);
    if (!names.length) throw new Error("ما عندك بروفايلات محفوظة");
    var name = names[Math.floor(Math.random() * names.length)];
    return "🎲 " + (await applyByName(name));
  };

  var renameProfile = function (oldName, newName, nick) {
    var s = getState();
    var profiles = Object.assign({}, s.profiles);
    var ns = Object.assign({}, s.ns);
    if (newName !== oldName) {
      if (profiles[newName]) throw new Error("فيه بروفايل بنفس الاسم");
      profiles[newName] = profiles[oldName];
      delete profiles[oldName];
      ns.names = (ns.names || []).map(function (n) { return n === oldName ? newName : n; });
    }
    profiles[newName] = Object.assign({}, profiles[newName], { nick: nick || null });
    setState({ profiles: profiles, ns: ns });
  };

  var deleteProfile = function (name) {
    var s = getState();
    var profiles = Object.assign({}, s.profiles);
    delete profiles[name];
    setState({
      profiles: profiles,
      ns: Object.assign({}, s.ns, { names: (s.ns.names || []).filter(function (n) { return n !== name; }) }),
    });
  };

  // ===== شاشة الإعدادات =====
  function SettingsComponent(props) {
    var U0;
    try { U0 = ui(); } catch (err) { return null; }
    var need = ["Stack", "TableRowGroup", "TableRow", "TableSwitchRow", "TextInput", "Button"];
    var miss = need.filter(function (n) { return !U0.D[n]; });
    ["View", "Text", "ScrollView"].forEach(function (n) { if (!U0.RN[n]) miss.push("RN." + n); });
    if (miss.length) {
      if (!U0.RN.Text) return null;
      return U0.R.createElement(U0.RN.Text, { style: { color: "#ffffff", padding: 16 } },
        "Per Profile: مكونات ناقصة: " + miss.join(", ") + "\nمفاتيح design: " + Object.keys(U0.D).slice(0, 40).join(", "));
    }
    return U0.R.createElement(SettingsInner, props);
  }

  function SettingsInner(props) {
    var U = ui();
    var R = U.R, RN = U.RN, D = U.D;
    var h = R.createElement;
    var storage = props.api.jsonStorage;
    var st = Object.assign({}, DEFAULTS, storage.use());
    st.profiles = st.profiles || {};
    st.ns = Object.assign({}, DEFAULTS.ns, st.ns || {});
    store = storage;
    mirror = st;

    var nameS = R.useState(""); var name = nameS[0], setName = nameS[1];
    var userS = R.useState(""); var userId = userS[0], setUserId = userS[1];
    var logS = R.useState(""); var log = logS[0], setLog = logS[1];
    var busyS = R.useState(false); var busy = busyS[0], setBusy = busyS[1];
    var editS = R.useState(null); var editing = editS[0], setEditing = editS[1];
    var enS = R.useState(""); var editName = enS[0], setEditName = enS[1];
    var ekS = R.useState(""); var editNick = ekS[0], setEditNick = ekS[1];
    var delS = R.useState(null); var confirmDel = delS[0], setConfirmDel = delS[1];
    var tkS = R.useState(0); var setTick = tkS[1];
    var knS = R.useState(""); var keyName = knS[0], setKeyName = knS[1];
    var koS = R.useState([]); var keyOut = koS[0], setKeyOut = koS[1];
    var kiS = R.useState(""); var keyIn = kiS[0], setKeyIn = kiS[1];

    var run = async function (fn) {
      if (busy) return;
      setBusy(true);
      try {
        var t = await fn();
        if (t) { setLog(String(t)); toast(String(t).split("\n")[0]); }
      } catch (err) {
        var m = "خطأ: " + ((err && err.message) || errText(err));
        setLog(m);
        toast(m);
      } finally {
        setBusy(false);
      }
    };

    var names = Object.keys(st.profiles);
    var Btn = function (key, text, onPress) {
      return h(D.Button, { key: key, text: text, size: "sm", onPress: onPress });
    };

    var body = h(D.Stack, { spacing: 24 }, [
      log ? h(D.TableRowGroup, { key: "log", title: "آخر نتيجة" }, h(D.TableRow, { label: log })) : null,

      h(D.TableRowGroup, { key: "cmd", title: "حالة أوامر /" }, [
        h(D.TableRow, { key: "cs", label: cmdStatus, subLabel: diag() }),
      ]),
      h(D.Button, {
        key: "cmdRetry",
        text: "إعادة تسجيل الأوامر",
        onPress: function () { if (retryCommands) retryCommands(); setTick(function (x) { return x + 1; }); },
      }),

      h(D.TableRowGroup, { key: "save", title: "حفظ" }, [
        h(D.TextInput, { key: "n", label: "اسم البروفايل", placeholder: "مثلاً: رسمي", value: name, onChange: setName, isClearable: true }),
      ]),
      h(D.Button, {
        key: "saveBtn",
        text: busy ? "جاري التنفيذ..." : "حفظ بروفايل السيرفر الحالي",
        onPress: function () {
          var n = name.trim();
          if (!n) return toast("اكتب اسم البروفايل");
          run(async function () { var t = await saveCurrent(n); setName(""); return t; });
        },
      }),

      h(D.TextInput, { key: "u", label: "أخذ بروفايل شخص (ID)", placeholder: "User ID", value: userId, onChange: setUserId, isClearable: true }),
      h(D.Button, {
        key: "stealBtn",
        text: "خذ بروفايله",
        onPress: function () {
          var id = userId.trim();
          if (!id) return toast("اكتب ID الشخص");
          run(async function () { var t = await stealUser(id, name.trim() || null, false); setUserId(""); return t; });
        },
      }),

      h(D.Button, { key: "rnd", text: "طبّق بروفايل عشوائي", onPress: function () { run(applyRandom); } }),

      h(D.TableRowGroup, { key: "keysT", title: "المفاتيح (مشاركة البروفايلات)" }, [
        h(D.TableRow, { key: "kx", label: "شارك بروفايلاتك بمفتاح", subLabel: "الصور تنزل من روابط ديسكورد عند الشخص اللي يدخل المفتاح" }),
      ]),
      h(D.TextInput, { key: "kn", label: "اسم البروفايل (فاضي = كل بروفايلاتك)", value: keyName, onChange: setKeyName, isClearable: true }),
      h(D.Button, {
        key: "kTake",
        text: "take key — خذ المفتاح",
        onPress: function () {
          try {
            var r = makeKey(keyName.trim() || null);
            setKeyOut(r.parts);
            var m = "المفتاح جاهز: " + r.count + " بروفايل في " + r.parts.length + " جزء" +
              (r.noImg ? "\n⚠️ " + r.noImg + " بروفايل بدون صور (احفظه من جديد)" : "");
            setLog(m); toast(m.split("\n")[0]);
          } catch (err) { toast(err.message); }
        },
      }),
      keyOut.length
        ? h(D.TableRowGroup, { key: "kp", title: "أجزاء المفتاح (" + keyOut.length + ") — انسخ كل جزء وأرسله بالترتيب" },
            keyOut.map(function (part, i) {
              return h(D.TableRow, {
                key: "kp" + i,
                label: "جزء " + (i + 1) + " / " + keyOut.length,
                subLabel: part.length + " حرف",
                trailing: Btn("c" + i, "نسخ", function () { toast(copyText(part) ? "اننسخ الجزء " + (i + 1) : "تعذّر النسخ"); }),
              });
            }))
        : null,
      h(D.TextInput, { key: "ki", label: "Insert the key — الصق المفتاح (أو الأجزاء) هنا", placeholder: "PP1:...", value: keyIn, onChange: setKeyIn, isClearable: true }),
      h(D.Button, {
        key: "kIns",
        text: "Insert the key",
        onPress: function () {
          var k = keyIn.trim();
          if (!k) return toast("الصق المفتاح أول");
          run(async function () { var t = await feedKeys(k); setKeyIn(""); return t; });
        },
      }),

      editing && st.profiles[editing]
        ? h(D.TableRowGroup, { key: "edit", title: "تعديل: " + editing }, [
            h(D.TextInput, { key: "en", label: "اسم البروفايل المحفوظ", value: editName, onChange: setEditName }),
            h(D.TextInput, { key: "ek", label: "الاسم المعروض في السيرفر (فاضي = ما يتغير)", value: editNick, onChange: setEditNick }),
            h(RN.View, { key: "eb", style: { flexDirection: "row", padding: 12 } }, [
              Btn("es", "حفظ", function () {
                try {
                  var nn = editName.trim();
                  if (!nn) return toast("الاسم فاضي");
                  renameProfile(editing, nn, editNick.trim());
                  setEditing(null);
                  toast("تم حفظ التعديل ✅");
                } catch (err) { toast(err.message); }
              }),
              Btn("ec", "إلغاء", function () { setEditing(null); }),
            ]),
          ])
        : null,

      h(D.TableRowGroup, { key: "list", title: "بروفايلاتك (" + names.length + ")" },
        names.length
          ? names.map(function (n) {
              return h(D.TableRow, {
                key: "p-" + n,
                label: n,
                subLabel: summary(st.profiles[n]),
                trailing: h(RN.View, { style: { flexDirection: "row" } }, [
                  Btn("a", "تطبيق", function () { run(function () { return applyByName(n); }); }),
                  Btn("e", "تعديل", function () {
                    setEditing(n); setEditName(n); setEditNick(st.profiles[n].nick || ""); setConfirmDel(null);
                  }),
                  Btn("d", confirmDel === n ? "تأكيد" : "حذف", function () {
                    if (confirmDel !== n) return setConfirmDel(n);
                    deleteProfile(n); setConfirmDel(null);
                    if (editing === n) setEditing(null);
                  }),
                ]),
              });
            })
          : h(D.TableRow, { label: "ما عندك بروفايلات محفوظة" })
      ),

      h(D.TableRowGroup, { key: "ns", title: "السيرفرات الجديدة" },
        [h(D.TableSwitchRow, {
          key: "nsOn",
          label: "تطبيق بروفايل تلقائياً عند دخول سيرفر جديد",
          subLabel: "ما حددت شي = يختار من كل بروفايلاتك",
          value: !!st.ns.enabled,
          onValueChange: function (v) { setState({ ns: Object.assign({}, st.ns, { enabled: v }) }); },
        })].concat(
          names.map(function (n) {
            return h(D.TableSwitchRow, {
              key: "ns-" + n,
              label: n,
              value: st.ns.names.indexOf(n) >= 0,
              onValueChange: function (v) {
                var arr = st.ns.names.filter(function (x) { return x !== n; });
                if (v) arr.push(n);
                setState({ ns: Object.assign({}, st.ns, { names: arr }) });
              },
            });
          })
        )
      ),
    ]);

    var content = h(RN.ScrollView, { contentContainerStyle: { paddingBottom: 40 } }, body);
    return U.Page ? h(U.Page, null, content) : content;
  }

  // ===== السيرفر الجديد =====
  var knownGuilds = null;
  var onGuildCreate = function (ev) {
    try {
      var g = ev && ev.guild;
      var id = g && g.id;
      if (!id || !knownGuilds || knownGuilds.has(id)) return;
      knownGuilds.add(id);
      if (g.joined_at && Date.now() - new Date(g.joined_at).getTime() > 5 * 60 * 1000) return;
      var s = getState();
      if (!s.ns.enabled) return;
      var pool = (s.ns.names || []).filter(function (n) { return s.profiles[n]; });
      if (!pool.length) pool = Object.keys(s.profiles);
      if (!pool.length) return;
      var pn = pool[Math.floor(Math.random() * pool.length)];
      setTimeout(async function () {
        try {
          var notes = await applyProfile(s.profiles[pn], id);
          toast("سيرفر جديد: طبّقت " + pn + (notes.length ? " (مع ملاحظات)" : " ✅"));
        } catch (_) {
          toast("فشل تطبيق بروفايل السيرفر الجديد");
        }
      }, 3000);
    } catch (_) {}
  };


  // ===== نافذة البطاقات (/show_per) =====
  const SHEET_KEY = "per-profiles-sheet";
  let sheetUI = null;

  const makeSheetUI = () => {
    const U = ui();
    const React = U.R;
    const h = React.createElement;
    const { View, Image, Text, ScrollView, TouchableOpacity, Dimensions, TextInput } = U.RN;

    const C = {
      bg: "#1e1f22", sheet: "#2b2d31", box: "#232428", line: "#3f4147", text: "#f2f3f5",
      sub: "#b5bac1", blurple: "#5865f2", green: "#248046", red: "#da373c", gray: "#4e5058", orange: "#c27c0e",
    };
    const toHex = (n) => "#" + Number(n).toString(16).padStart(6, "0");
    const decoUrl = (asset) =>
      `https://cdn.discordapp.com/avatar-decoration-presets/${asset}.png?size=160&passthrough=true`;

  function ProfileCard({ d, name, W }) {
    const bannerH = Math.round(W / 2.5);
    const AV = 84;
    const accent =
      d.theme_colors?.[1] != null
        ? toHex(d.theme_colors[1])
        : d.accent_color != null
        ? toHex(d.accent_color)
        : C.blurple;
    const bannerSrc = d.bannerUrl || d.banner;
    const avatarSrc = d.avatarUrl || d.avatar;

    const ns = d.display_name_styles;
    const nameColors = Array.isArray(ns?.colors) ? ns.colors : [];
    const nameColor = nameColors[0] != null ? toHex(nameColors[0]) : C.text;

    const colors = [];
    (d.theme_colors ?? []).forEach((c) => colors.push(c));
    if (d.accent_color != null && !colors.includes(d.accent_color)) colors.push(d.accent_color);

    const label = (t) =>
      h(Text, { style: { color: C.sub, fontSize: 10, fontWeight: "700", marginBottom: 8, textAlign: "center" } }, t);

    const box = (key, title, children) =>
      h(
        View,
        {
          key,
          style: {
            flex: 1,
            backgroundColor: C.box,
            borderRadius: 12,
            borderWidth: 1,
            borderColor: C.line,
            padding: 6,
            marginHorizontal: 2,
            minHeight: 86,
            alignItems: "center",
          },
        },
        [label(title), children]
      );

    const dots = (arr, size) =>
      h(
        View,
        { style: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center" } },
        arr.slice(0, 6).map((c, i) =>
          h(View, {
            key: "dot" + i,
            style: { width: size, height: size, borderRadius: size / 2, backgroundColor: toHex(c), margin: 2, borderWidth: 1, borderColor: "#ffffff55" },
          })
        )
      );

    return h(
      View,
      {
        style: {
          width: W,
          backgroundColor: C.bg,
          borderRadius: 18,
          overflow: "hidden",
          borderWidth: 1,
          borderColor: C.line,
        },
      },
      [
        bannerSrc
          ? h(Image, { key: "b", source: { uri: bannerSrc }, style: { width: W, height: bannerH }, resizeMode: "cover" })
          : h(View, { key: "b", style: { width: W, height: bannerH, backgroundColor: accent } }),

        h(
          View,
          { key: "av", style: { paddingHorizontal: 16 } },
          h(
            View,
            { style: { width: AV, height: AV, marginTop: -AV / 2, alignItems: "center", justifyContent: "center" } },
            [
              h(
                View,
                {
                  key: "ring",
                  style: {
                    width: AV,
                    height: AV,
                    borderRadius: AV / 2,
                    borderWidth: 5,
                    borderColor: C.bg,
                    backgroundColor: C.gray,
                    overflow: "hidden",
                  },
                },
                avatarSrc
                  ? h(Image, { source: { uri: avatarSrc }, style: { width: "100%", height: "100%" } })
                  : null
              ),
              d.avatar_decoration?.asset
                ? h(Image, {
                    key: "deco",
                    source: { uri: decoUrl(d.avatar_decoration.asset) },
                    style: { position: "absolute", width: AV * 1.2, height: AV * 1.2 },
                  })
                : null,
            ]
          )
        ),

        h(
          View,
          { key: "info", style: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 6 } },
          [
            h(Text, { key: "n", style: { color: nameColor, fontSize: 21, fontWeight: "800" } }, d.nick || name),
            d.pronouns ? h(Text, { key: "p", style: { color: C.sub, fontSize: 13, marginTop: 2 } }, d.pronouns) : null,
            d.bio ? h(Text, { key: "bio", style: { color: C.text, fontSize: 14, marginTop: 8 } }, d.bio) : null,
          ]
        ),

        h(
          View,
          { key: "boxes", style: { flexDirection: "row", padding: 8, paddingTop: 8 } },
          [
            box("c", "الألوان", colors.length ? dots(colors, 20) : h(Text, { style: { color: C.sub } }, "—")),
            box(
              "e",
              "الافكت",
              d.profile_effect_id
                ? h(
                    View,
                    { style: { width: 40, height: 40, borderRadius: 12, backgroundColor: accent + "55", borderWidth: 1, borderColor: accent, alignItems: "center", justifyContent: "center" } },
                    h(Text, { style: { fontSize: 20 } }, "✨")
                  )
                : h(Text, { style: { color: C.sub } }, "—")
            ),
            box(
              "d",
              "الديكوريشن",
              d.avatar_decoration?.asset
                ? h(Image, { source: { uri: decoUrl(d.avatar_decoration.asset) }, style: { width: 44, height: 44 } })
                : h(Text, { style: { color: C.sub } }, "—")
            ),
            box(
              "s",
              "ستايل الاسم",
              ns
                ? h(View, { style: { alignItems: "center" } }, [
                    nameColors.length ? dots(nameColors, 16) : null,
                    ns.font_id != null
                      ? h(Text, { key: "f", style: { color: C.sub, fontSize: 10, marginTop: 2 } }, "خط " + ns.font_id)
                      : null,
                    ns.effect_id != null
                      ? h(Text, { key: "ef", style: { color: C.sub, fontSize: 10 } }, "تأثير " + ns.effect_id)
                      : null,
                  ])
                : h(Text, { style: { color: C.sub } }, "—")
            ),
          ]
        ),
      ]
    );
  }

    function SheetView(props) {
      const W = Dimensions.get("window").width - 88;
      const now = () => getState().profiles;
      const names0 = Object.keys(now());
      const startSel = props.initSel && now()[props.initSel] ? props.initSel : names0[0] || null;
      const [sel, setSel] = React.useState(startSel);
      const [busy, setBusy] = React.useState(false);
      const [confirmDel, setConfirmDel] = React.useState(false);
      const [, bump] = React.useState(0);
      const [closed, setClosed] = React.useState(false);
      const [editing, setEditing] = React.useState(!!props.initEdit && !!startSel);
      const [nameIn, setNameIn] = React.useState(props.initEdit && startSel ? startSel : "");
      const [nickIn, setNickIn] = React.useState(
        props.initEdit && startSel ? (now()[startSel] || {}).nick || "" : ""
      );

      const profiles = now();
      const names = Object.keys(profiles);
      const current = sel && profiles[sel] ? sel : names[0] || null;
      const d = current ? profiles[current] : null;

      const close = () => {
        props.close();
        setClosed(true);
      };

      const button = (key, text, onPress, bg) =>
        h(
          TouchableOpacity,
          {
            key,
            onPress,
            style: { flex: 1, backgroundColor: bg, paddingVertical: 14, borderRadius: 12, alignItems: "center", marginHorizontal: 4 },
          },
          h(Text, { style: { color: "#fff", fontSize: 15, fontWeight: "700" } }, text)
        );

      const input = (key, title, value, onChange, placeholder) =>
        h(View, { key, style: { marginBottom: 10 } }, [
          h(Text, { key: "l", style: { color: C.sub, fontSize: 12, fontWeight: "700", marginBottom: 4 } }, title),
          h(TextInput, {
            key: "i",
            value,
            onChangeText: onChange,
            placeholder,
            placeholderTextColor: C.gray,
            style: {
              backgroundColor: C.box, color: C.text, borderRadius: 10, borderWidth: 1, borderColor: C.line,
              paddingHorizontal: 12, paddingVertical: 10, fontSize: 15,
            },
          }),
        ]);

      if (closed) return h(View, { style: { height: 1 } });

      const startEdit = () => {
        setNameIn(current);
        setNickIn((d && d.nick) || "");
        setConfirmDel(false);
        setEditing(true);
      };

      const saveEdit = () => {
        const nn = nameIn.trim();
        if (!nn) return toast("اسم البروفايل فاضي");
        try {
          renameProfile(current, nn, nickIn.trim());
        } catch (err) {
          return toast((err && err.message) || "تعذّر الحفظ");
        }
        setSel(nn);
        setEditing(false);
        bump((x) => x + 1);
        toast("تم حفظ التعديل ✅");
      };

      const chips = h(
        ScrollView,
        { key: "chips", horizontal: true, showsHorizontalScrollIndicator: false, style: { flexGrow: 0, marginBottom: 12 } },
        names.map((n) =>
          h(
            TouchableOpacity,
            {
              key: "chip-" + n,
              onPress: () => { setSel(n); setConfirmDel(false); setEditing(false); },
              style: {
                backgroundColor: n === current ? C.blurple : C.box,
                paddingVertical: 9, paddingHorizontal: 16, borderRadius: 20, marginRight: 8,
                borderWidth: 1, borderColor: n === current ? C.blurple : C.line,
              },
            },
            h(Text, { style: { color: "#fff", fontWeight: "700" } }, n)
          )
        )
      );

      let bottom;
      if (editing) {
        bottom = [
          h(View, { key: "form", style: { marginTop: 14 } }, [
            input("n", "اسم البروفايل المحفوظ", nameIn, setNameIn, "اسم البروفايل"),
            input("k", "الاسم المعروض في السيرفر (فاضي = ما يتغير)", nickIn, setNickIn, "displayName"),
          ]),
          h(View, { key: "btns", style: { flexDirection: "row" } }, [
            button("save", "حفظ", saveEdit, C.green),
            button("cancel", "إلغاء", () => setEditing(false), C.gray),
          ]),
        ];
      } else {
        bottom = [
          h(View, { key: "btns", style: { flexDirection: "row", marginTop: 14 } }, [
            button("apply", busy ? "جاري التطبيق..." : "تطبيق", async () => {
              if (busy) return;
              if (!props.guildId) {
                close();
                return sendLocal(props.ctx, "ادخل سيرفر أول.");
              }
              setBusy(true);
              let notes = [];
              try {
                notes = await applyProfile(d, props.guildId);
              } catch (err) {
                notes = [(err && err.message) || errText(err)];
              }
              setBusy(false);
              close();
              sendLocal(props.ctx, "تم تطبيق " + current + " ✅" + (notes.length ? "\n" + notes.join("\n") : ""));
            }, C.green),
            button("edit", "تعديل", startEdit, C.blurple),
            button("del", confirmDel ? "تأكيد الحذف" : "حذف", () => {
              if (!confirmDel) return setConfirmDel(true);
              deleteProfile(current);
              setConfirmDel(false);
              setSel(Object.keys(now())[0] || null);
              bump((x) => x + 1);
            }, C.red),
            button("close", "إغلاق", close, C.gray),
          ]),
        ];
      }

      return h(
        View,
        {
          style: {
            backgroundColor: C.sheet, borderRadius: 20, paddingTop: 14, paddingBottom: 18, paddingHorizontal: 12,
            maxHeight: Dimensions.get("window").height * 0.8,
          },
        },
        !names.length
          ? [
              h(Text, { key: "e", style: { color: C.text, textAlign: "center", fontSize: 16, marginVertical: 24 } },
                "ما عندك بروفايلات محفوظة.\nاحفظ واحد بـ /save_pr"),
              h(View, { key: "r", style: { flexDirection: "row" } }, button("c", "إغلاق", close, C.gray)),
            ]
          : [
              chips,
              h(ScrollView, { key: "card", style: { flexGrow: 0 }, showsVerticalScrollIndicator: false },
                h(ProfileCard, { d, name: current, W })),
              ...bottom,
            ]
      );
    }

    return { SheetView };
  };

  const openSheet = (ctx, opts) => {
    opts = opts || {};
    try {
      const U = ui();
      const D = U.D;
      const AC = safe(() => V.discord.actions.AlertActionCreators);
      if (!AC || !AC.openAlert || !D.AlertModal || !D.AlertActionButton) throw new Error("no alert");
      if (!sheetUI) sheetUI = makeSheetUI();
      const h = U.R.createElement;
      const close = () => {
        safe(() => AC.dismissAlert && AC.dismissAlert(SHEET_KEY));
        safe(() => AC.closeAlert && AC.closeAlert(SHEET_KEY));
      };
      AC.openAlert(
        SHEET_KEY,
        h(D.AlertModal, {
          title: "بروفايلاتك",
          extraContent: h(sheetUI.SheetView, {
            ctx,
            close,
            guildId: (ctx && ctx.guild && ctx.guild.id) || currentGuildId(),
            initSel: opts.sel,
            initEdit: opts.edit,
          }),
          actions: h(D.AlertActionButton, { text: "إغلاق", variant: "secondary" }),
        })
      );
      return true;
    } catch (err) {
      sendLocal(ctx, listText());
      return false;
    }
  };

  // ===== أوامر slash =====
  var argOf = function (args, n) {
    var a = args && args.find ? args.find(function (x) { return x.name === n; }) : null;
    return a ? a.value : undefined;
  };

  var opt = function (name, desc, type, required, choices) {
    var o = {
      name: name, displayName: name, serverLocalizedName: name, untranslatedName: name,
      description: desc, displayDescription: desc, serverLocalizedDescription: desc, untranslatedDescription: desc,
      type: type, required: !!required,
    };
    if (choices) {
      o.choices = choices.map(function (c) {
        var v = typeof c === "string" ? c : c.value;
        var l = typeof c === "string" ? c : c.label;
        return { name: v, displayName: l, serverLocalizedName: l, untranslatedName: l, label: l, value: v };
      });
    }
    return o;
  };

  var listText = function () {
    var names = Object.keys(getState().profiles);
    if (!names.length) return "ما عندك بروفايلات محفوظة.";
    return "بروفايلاتك (" + names.length + "):\n" + names.map(function (n, i) {
      return (i + 1) + ". **" + n + "** — " + summary(getState().profiles[n]);
    }).join("\n");
  };

  var COMMANDS = [
    ["save_pr", "احفظ بروفايل السيرفر الحالي", [opt("name", "اسم البروفايل", 3, true)],
      function (a) { return saveCurrent(argOf(a, "name")); }],
    ["set_pr", "طبّق بروفايل محفوظ (بدون اسم = يعرض القائمة)", [opt("name", "اسم البروفايل", 3, false)],
      function (a, ctx) { var n = argOf(a, "name"); if (n) return applyByName(n); openSheet(ctx); return ""; }],
    ["show_per", "اعرض بروفايلاتك كبطاقات", [],
      function (a, ctx) { openSheet(ctx); return ""; }],
    ["edit_per", "عدّل بروفايل محفوظ (الاسم المحفوظ أو الاسم المعروض)",
      [opt("name", "اسم البروفايل", 3, true), opt("new_name", "اسم البروفايل الجديد", 3, false), opt("display_name", "الاسم المعروض (اكتب - للمسح)", 3, false)],
      function (a, ctx) {
        var n = argOf(a, "name"), nn = argOf(a, "new_name"), dn = argOf(a, "display_name");
        var d = getState().profiles[n];
        if (!d) throw new Error("ما لقيت بروفايل " + n);
        if (nn == null && dn == null) { openSheet(ctx, { sel: n, edit: true }); return ""; }
        var nick = d.nick;
        if (dn != null) { var v = String(dn).trim(); nick = v === "" || v === "-" ? null : v; }
        var finalName = nn && String(nn).trim() ? String(nn).trim() : n;
        renameProfile(n, finalName, nick);
        return "تم تعديل **" + finalName + "** ✅";
      }],
    ["rename_pr", "غيّر اسم بروفايل محفوظ", [opt("name", "الاسم الحالي", 3, true), opt("new_name", "الاسم الجديد", 3, true)],
      function (a) {
        var n = argOf(a, "name"), nn = String(argOf(a, "new_name") || "").trim();
        var d = getState().profiles[n];
        if (!d) throw new Error("ما لقيت بروفايل " + n);
        if (!nn) throw new Error("اكتب الاسم الجديد");
        renameProfile(n, nn, d.nick);
        return "تم تغيير الاسم من **" + n + "** إلى **" + nn + "** ✅";
      }],
    ["delete_pr", "احذف بروفايل محفوظ", [opt("name", "اسم البروفايل", 3, true)],
      function (a) {
        var n = argOf(a, "name");
        if (!getState().profiles[n]) throw new Error("ما لقيت بروفايل " + n);
        deleteProfile(n);
        return "تم حذف **" + n + "** 🗑️";
      }],
    ["stole_per", "خذ بروفايل شخص ثاني",
      [opt("user", "الشخص", 6, true), opt("name", "اسم تحفظه به (اختياري)", 3, false), opt("apply", "طبّقه مباشرة", 5, false)],
      function (a) { return stealUser(argOf(a, "user"), argOf(a, "name") || null, !!argOf(a, "apply")); }],
    ["key_per", "شارك بروفايلاتك بمفتاح: take key لأخذ مفتاح، Insert the key لإدخال مفتاح",
      [opt("action", "اختر العملية", 3, true, [{ value: "take", label: "take key" }, { value: "insert", label: "Insert the key" }]),
       opt("key", "المفتاح أو جزء منه (مع Insert the key)", 3, false),
       opt("name", "اسم بروفايل واحد (مع take key، فاضي = كل بروفايلاتك)", 3, false)],
      function (a) {
        if (argOf(a, "action") === "insert") {
          var k = argOf(a, "key");
          if (!k) throw new Error("الصق المفتاح (أو الجزء) في خيار key");
          return feedKeys(k);
        }
        var r = makeKey(argOf(a, "name") || null);
        if (r.parts.length === 1) copyText(r.parts[0]);
        return [keyTakeText(r)].concat(r.parts.map(function (x) { return "`" + x + "`"; }));
      }],
    ["random_per", "طبّق بروفايل عشوائي من بروفايلاتك", [],
      function () { return applyRandom(); }],
    ["newserver_per", "اختيار بروفايل تلقائياً عند دخول سيرفر جديد (الاختيار من الإعدادات)",
      [opt("mode", "on للتشغيل، off للإيقاف", 3, true, ["on", "off"])],
      function (a) {
        var on = argOf(a, "mode") === "on";
        setState({ ns: Object.assign({}, getState().ns, { enabled: on }) });
        return on ? "تم تشغيل البروفايل التلقائي للسيرفرات الجديدة ✅" : "تم إيقاف البروفايل التلقائي ⏹️";
      }],
  ];

  var cmdStatus = "⏳ لم يبدأ التسجيل";
  var retryCommands = null;
  var diag = function () {
    var pk = safe(function () { return Object.keys(V.plugins || {}).slice(0, 25).join(", "); }, "");
    var gk = safe(function () {
      return Object.keys(globalThis).filter(function (k) { return k.indexOf("__c") === 0 || /util/i.test(k); }).slice(0, 15).join(", ");
    }, "");
    var uk = safe(function () { return Object.keys(V.plugins.utils || {}).slice(0, 30).join(", "); }, "");
    var ck = safe(function () { return Object.keys(V.plugins.constants || {}).slice(0, 30).join(", "); }, "");
    var fk = safe(function () { var m = find("registerCommand"); return m ? "found" : "none"; }, "err");
    return "valenced.plugins: " + (pk || "—") + "\nutils: " + (uk || "—") + "\nconstants: " + (ck || "—") +
      "\nglobal: " + (gk || "—") + "\nfind(registerCommand): " + fk;
  };

  var enumValue = function (name, key, fallback) {
    try {
      var m = find(name);
      var v = m && m[name] && m[name][key];
      return v != null ? v : fallback;
    } catch (_) {
      return fallback;
    }
  };

  // رسالة محلية (ما تنرسل للقناة)
  var sendLocal = function (ctx, text) {
    var ch = ctx && ctx.channel && ctx.channel.id;
    var bm = find("sendBotMessage");
    if (bm && bm.sendBotMessage && ch) {
      try { bm.sendBotMessage(ch, text); return; } catch (_) {}
    }
    toast(String(text).split("\n")[0]);
  };

  var registerCommands = function (api) {
    var installed = false;

    var mkCmd = function (c, i) {
      var desc = c[1];
      return {
        id: String(-81000 - i),
        name: c[0], displayName: c[0], serverLocalizedName: c[0], untranslatedName: c[0],
        description: desc, displayDescription: desc, serverLocalizedDescription: desc, untranslatedDescription: desc,
        type: 1,
        inputType: enumValue("ApplicationCommandInputType", "BUILT_IN_TEXT", 1),
        applicationId: "-1",
        options: c[2],
        predicate: function () { return true; },
        execute: async function (args, ctx) {
          try {
            var out = await c[3](args, ctx);
            (Array.isArray(out) ? out : [out]).forEach(function (t) { if (t != null && t !== "") sendLocal(ctx, String(t)); });
          } catch (err) {
            sendLocal(ctx, "خطأ: " + ((err && err.message) || errText(err)));
          }
        },
      };
    };

    var install = function () {
      if (installed) return;
      installed = true;
      var cmds = COMMANDS.map(mkCmd);
      cmdStatus = "⏳ أدوّر على getBuiltInCommands";
      api.cleanup(F.getModules(F.filters.withProps("getBuiltInCommands"), function (mod) {
        api.cleanup(V.patcher.instead(mod, "getBuiltInCommands", function (args, orig) {
          var result = orig.apply(this, args);
          try {
            var types = args && args[0];
            var wantsChat = Array.isArray(types) ? types.indexOf(1) >= 0 : types == null || types === 1;
            if (!wantsChat || !Array.isArray(result)) return result;
            if (result.some(function (x) { return x && String(x.id) === cmds[0].id; })) return result;
            return result.concat(cmds);
          } catch (_) {
            return result;
          }
        }));
        cmdStatus = "✅ الأوامر مسجّلة (" + cmds.length + ") عبر getBuiltInCommands";
      }));
    };

    install();
    retryCommands = install;
  };

  return (
    (e.default = plugin({
      jsonStorage: { load: true, default: DEFAULTS },
      start: function (ctx) {
        store = ctx.jsonStorage;
        knownGuilds = new Set(Object.keys(safe(function () { return Stores.GuildStore.getGuilds(); }, {}) || {}));
        registerCommands(ctx);
        if (Dispatcher && Dispatcher.subscribe) {
          Dispatcher.subscribe("GUILD_CREATE", onGuildCreate);
          ctx.cleanup(function () { safe(function () { Dispatcher.unsubscribe("GUILD_CREATE", onGuildCreate); }); });
        }
      },
      SettingsComponent: SettingsComponent,
    })),
    e
  );
})({});
