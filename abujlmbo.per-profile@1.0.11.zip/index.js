(function (e) {
  Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });

  var V = valenced;
  var safe = function (f, d) {
    try {
      var r = f();
      return r === undefined ? d : r;
    } catch (_) {
      return d;
    }
  };
  var norm = function (m) {
    return m && m.default && typeof m.default !== "string" && !m.createElement && !m.View ? m.default : m;
  };

  var F = V.modules.finders;
  var find = function () {
    var p = Array.prototype.slice.call(arguments);
    return safe(function () {
      return F.lookupModule(F.filters.withProps.apply(null, p))[0];
    });
  };

  // ===== الوحدات =====
  var Stores = new Proxy({}, { get: function (_, k) { return V.discord.flux.Stores[k]; } });
  var Dispatcher = safe(function () { return V.discord.common.flux.Dispatcher; });
  var Toast = safe(function () { return V.discord.actions.ToastActionCreators; });
  var httpCache = null;
  var getHTTP = function () {
    if (httpCache) return httpCache;
    var m = find("HTTP", "post");
    var h = (m && m.HTTP) || find("getAPIBaseURL", "get", "patch");
    if (!h || !h.get) throw new Error("HTTP module not found");
    httpCache = h;
    return h;
  };
  var HTTP = {
    get: function (o) { return getHTTP().get(o); },
    patch: function (o) { return getHTTP().patch(o); },
  };

  var uiCache = null;
  var ui = function () {
    if (uiCache) return uiCache;
    var R = norm(safe(function () { return V.externals.React; })) || find("createElement", "useState");
    var RN = norm(safe(function () { return V.externals.ReactNative; })) || find("View", "Text", "ScrollView");
    var dm = safe(function () { return V.discord.design; });
    var D = dm && (dm.Design || dm);
    var Page = norm(safe(function () { return V.components.Page; }));
    var okType = function (x) { return typeof x === "function" || (x && typeof x === "object" && x.$$typeof); };
    if (!okType(Page)) Page = null;
    if (!R) throw new Error("React not found");
    if (!RN) throw new Error("ReactNative not found");
    if (!D) throw new Error("Design components not found");
    uiCache = { R: R, RN: RN, D: D, Page: Page };
    return uiCache;
  };

  // ===== التخزين =====
  var DEFAULTS = { lang: "en", autoBackup: true, folders: [], profiles: {}, ns: { enabled: false, names: [] } };
  var store = null;
  var mirror = DEFAULTS;

  var recentPatch = null;
  var getState = function () {
    var s = safe(function () { return store && store.cache ? store.cache : undefined; });
    s = s || safe(function () { return store && typeof store.get === "function" ? store.get() : undefined; });
    s = s || mirror;
    if (recentPatch && Date.now() - recentPatch.t < 3000) s = Object.assign({}, s, recentPatch.patch);
    return Object.assign({}, DEFAULTS, s, {
      profiles: (s && s.profiles) || {},
      folders: (s && Array.isArray(s.folders) && s.folders) || [],
      ns: Object.assign({}, DEFAULTS.ns, (s && s.ns) || {}),
    });
  };
  var setState = function (patch) {
    mirror = Object.assign({}, getState(), patch);
    var prev = recentPatch && Date.now() - recentPatch.t < 3000 ? recentPatch.patch : {};
    recentPatch = { t: Date.now(), patch: Object.assign({}, prev, patch) };
    if (store && typeof store.set === "function") store.set(patch);
    if (patch.profiles || patch.folders) scheduleAuto();
  };

  var STR = { en: {
    "av_none": "none",
    "av_guild": "server-specific",
    "av_global": "global",
    "s_avatar": "avatar",
    "s_banner": "banner",
    "s_effect": "effect",
    "s_deco": "decoration",
    "s_namestyle": "name style",
    "s_bio": "bio",
    "s_nick": "name: {v}",
    "s_empty": "empty",
    "n_nick": "Nickname: {e}",
    "n_avatar_rl": "Avatar: Discord limits changes, try again in 10-15 minutes",
    "n_avatar": "Avatar: {e}",
    "n_ns_nochange": "Name style: unchanged (you probably don't own the font or effect)",
    "n_ns_err": "Name style: {e}",
    "n_bbb": "Banner/colors/bio: {e}",
    "n_eff_nochange": "Effect: unchanged (current: {v})",
    "none_word": "none",
    "n_eff_err": "Effect: {e}",
    "n_deco_fail": "Decoration was not applied",
    "e_nopro": "You have no saved profiles",
    "e_nf": "Profile not found: {n}",
    "e_keyempty": "The key is empty",
    "img_av_fail": "{n}: couldn't load the avatar",
    "img_bn_fail": "{n}: couldn't load the banner",
    "list_sep": ", ",
    "k_added": "Imported {c} profile(s) ✅\n{names}",
    "k_missing": "Received {have} of {n} parts. Missing: {miss}\nSend the rest with the same command (Insert the key).",
    "k_corrupt": "The key is corrupted. Make sure you copied all the parts completely.",
    "k_old_corrupt": "The old-style key is corrupted or incomplete",
    "k_notfound": "No valid key found in the text (it must start with PP2.)",
    "k_take_many": "Key for {count} profile(s) in {parts} parts.\nSend the parts in order (one message each). To copy a part, long-press its message.",
    "k_take_one": "Key for {count} profile(s) in 1 part.\nCopied to the clipboard.",
    "k_noimg": "⚠️ {n} profile(s) have no image links. Save them again so their images carry over.",
    "e_needguild": "Open a server first (open any server, then come back)",
    "saved": "Saved {name} ✅ (avatar: {src})",
    "stole": "Took the profile {name} ✅",
    "applied_now": "Applied",
    "applied": "Applied {name}",
    "e_dupname": "A profile with that name already exists",
    "err_prefix": "Error: ",
    "last_result": "Last result",
    "cmd_status_title": "Slash commands (/)",
    "re_register": "Re-register commands",
    "save_title": "Save",
    "profile_name": "Profile name",
    "profile_ph": "e.g. Formal",
    "busy": "Working...",
    "save_cur": "Save the current server profile",
    "type_name": "Enter a profile name",
    "steal_label": "Take someone's profile (ID)",
    "steal_btn": "Take their profile",
    "type_id": "Enter the user's ID",
    "random_btn": "Apply a random profile",
    "keys_title": "Keys (share profiles)",
    "keys_row": "Share your profiles with a key",
    "keys_sub": "Images are downloaded from Discord links by whoever imports the key",
    "key_name_label": "Profile name (empty = all your profiles)",
    "take_btn": "take key",
    "key_ready": "Key ready: {count} profile(s) in {parts} part(s)",
    "parts_title": "Key parts ({n}) — copy each part and send them in order",
    "part_label": "Part {i} / {n}",
    "chars": "{n} characters",
    "copy": "Copy",
    "copied": "Copied part {i}",
    "copy_fail": "Couldn't copy",
    "insert_label": "Insert the key — paste the key (or its parts) here",
    "paste_first": "Paste the key first",
    "edit_title": "Edit: {n}",
    "saved_name_label": "Saved profile name",
    "display_label": "Display name in the server (empty = unchanged)",
    "save_btn": "Save",
    "cancel": "Cancel",
    "name_empty": "The name is empty",
    "edit_saved": "Changes saved ✅",
    "your_profiles": "Your profiles ({n})",
    "apply_btn": "Apply",
    "edit_btn": "Edit",
    "delete_btn": "Delete",
    "confirm_btn": "Confirm",
    "no_profiles_row": "You have no saved profiles",
    "save_hint": "Save one with /save_pr",
    "ns_title": "New servers",
    "ns_label": "Apply a profile automatically when joining a new server",
    "ns_sub": "Nothing selected = picks from all your profiles",
    "ns_applied": "New server: applied {n}",
    "with_notes": " (with notes)",
    "ns_fail": "Failed to apply the new-server profile",
    "save_fail": "Couldn't save",
    "need_server": "Open a server first.",
    "close": "Close",
    "list_none": "You have no saved profiles.",
    "list_head": "Your profiles ({n}):",
    "lang_title": "Language",
    "lang_note": "Slash command descriptions update after restarting the app",
    "cmd_pending": "⏳ Commands not registered yet",
    "cmd_search": "⏳ Looking for getBuiltInCommands",
    "cmd_ok": "✅ Commands registered ({n}) via getBuiltInCommands",
    "c_save": "Save the current server profile",
    "o_name": "Profile name",
    "c_set": "Apply a saved profile (no name = show the list)",
    "c_show": "Show your profiles as a list",
    "c_edit": "Edit a saved profile (saved name or display name)",
    "o_newname": "New profile name",
    "o_display": "Display name (type - to clear)",
    "edited": "Edited **{n}** ✅",
    "c_rename": "Rename a saved profile",
    "o_cur": "Current name",
    "o_new": "New name",
    "e_typenew": "Enter the new name",
    "renamed": "Renamed **{a}** to **{b}** ✅",
    "c_delete": "Delete a saved profile",
    "deleted": "Deleted **{n}** 🗑️",
    "c_steal": "Take another person's profile",
    "o_user": "The person",
    "o_saveas": "Name to save it as (optional)",
    "o_applynow": "Apply it right away",
    "c_key": "Share profiles with a key: take key to get one, Insert the key to import one",
    "o_action": "Choose the action",
    "o_key": "The key or a part of it (with Insert the key)",
    "o_keyname": "A single profile name (with take key; empty = all your profiles)",
    "e_pastekey": "Paste the key (or a part) in the key option",
    "c_random": "Apply a random profile from yours",
    "c_ns": "Pick a profile automatically when joining a new server (choose profiles in settings)",
    "o_mode": "on to enable, off to disable",
    "ns_on": "Auto profile for new servers enabled ✅",
    "ns_off": "Auto profile for new servers disabled ⏹️"
  }, ar: {
    "av_none": "ما فيه",
    "av_guild": "خاص بالسيرفر",
    "av_global": "عام",
    "s_avatar": "أفتار",
    "s_banner": "بنر",
    "s_effect": "افكت",
    "s_deco": "ديكوريشن",
    "s_namestyle": "ستايل اسم",
    "s_bio": "بايو",
    "s_nick": "اسم: {v}",
    "s_empty": "فاضي",
    "n_nick": "النك نيم: {e}",
    "n_avatar_rl": "الأفتار: ديسكورد يحدّ التغيير، جرّب بعد 10-15 دقيقة",
    "n_avatar": "الأفتار: {e}",
    "n_ns_nochange": "ستايل الاسم: ما تغيّر (غالباً ما تملك الخط أو التأثير)",
    "n_ns_err": "ستايل الاسم: {e}",
    "n_bbb": "البنر/الألوان/البايو: {e}",
    "n_eff_nochange": "الافكت: ما تغيّر (الحالي {v})",
    "none_word": "ما فيه",
    "n_eff_err": "الافكت: {e}",
    "n_deco_fail": "الديكوريشن ما انطبق",
    "e_nopro": "ما عندك بروفايلات محفوظة",
    "e_nf": "ما لقيت بروفايل {n}",
    "e_keyempty": "المفتاح فاضي",
    "img_av_fail": "{n}: تعذّر تحميل الأفتار",
    "img_bn_fail": "{n}: تعذّر تحميل البنر",
    "list_sep": "، ",
    "k_added": "تم أخذ {c} بروفايل ✅\n{names}",
    "k_missing": "استلمت {have} من {n} أجزاء. ناقص: {miss}\nأرسل الباقي بنفس الأمر (Insert the key).",
    "k_corrupt": "المفتاح تالف، تأكد إنك نسخت كل الأجزاء كاملة",
    "k_old_corrupt": "المفتاح القديم تالف أو ناقص",
    "k_notfound": "ما لقيت مفتاح صحيح في النص (لازم يبدأ بـ PP2.)",
    "k_take_many": "مفتاح {count} بروفايل في {parts} أجزاء.\nأرسل الأجزاء بالترتيب (كل جزء رسالة)، وللنسخ اضغط مطوّلاً على الرسالة.",
    "k_take_one": "مفتاح {count} بروفايل في جزء.\nاننسخ للحافظة.",
    "k_noimg": "⚠️ {n} بروفايل بدون روابط صور، احفظه من جديد عشان تنتقل صوره.",
    "e_needguild": "ادخل سيرفر أول (افتح أي سيرفر ثم ارجع للإعدادات)",
    "saved": "تم حفظ {name} ✅ (أفتار: {src})",
    "stole": "أخذت بروفايل {name} ✅",
    "applied_now": "تم تطبيقه",
    "applied": "تم تطبيق {name}",
    "e_dupname": "فيه بروفايل بنفس الاسم",
    "err_prefix": "خطأ: ",
    "last_result": "آخر نتيجة",
    "cmd_status_title": "حالة أوامر /",
    "re_register": "إعادة تسجيل الأوامر",
    "save_title": "حفظ",
    "profile_name": "اسم البروفايل",
    "profile_ph": "مثلاً: رسمي",
    "busy": "جاري التنفيذ...",
    "save_cur": "حفظ بروفايل السيرفر الحالي",
    "type_name": "اكتب اسم البروفايل",
    "steal_label": "أخذ بروفايل شخص (ID)",
    "steal_btn": "خذ بروفايله",
    "type_id": "اكتب ID الشخص",
    "random_btn": "طبّق بروفايل عشوائي",
    "keys_title": "المفاتيح (مشاركة البروفايلات)",
    "keys_row": "شارك بروفايلاتك بمفتاح",
    "keys_sub": "الصور تنزل من روابط ديسكورد عند الشخص اللي يدخل المفتاح",
    "key_name_label": "اسم البروفايل (فاضي = كل بروفايلاتك)",
    "take_btn": "take key — خذ المفتاح",
    "key_ready": "المفتاح جاهز: {count} بروفايل في {parts} جزء",
    "parts_title": "أجزاء المفتاح ({n}) — انسخ كل جزء وأرسله بالترتيب",
    "part_label": "جزء {i} / {n}",
    "chars": "{n} حرف",
    "copy": "نسخ",
    "copied": "اننسخ الجزء {i}",
    "copy_fail": "تعذّر النسخ",
    "insert_label": "Insert the key — الصق المفتاح (أو الأجزاء) هنا",
    "paste_first": "الصق المفتاح أول",
    "edit_title": "تعديل: {n}",
    "saved_name_label": "اسم البروفايل المحفوظ",
    "display_label": "الاسم المعروض في السيرفر (فاضي = ما يتغير)",
    "save_btn": "حفظ",
    "cancel": "إلغاء",
    "name_empty": "الاسم فاضي",
    "edit_saved": "تم حفظ التعديل ✅",
    "your_profiles": "بروفايلاتك ({n})",
    "apply_btn": "تطبيق",
    "edit_btn": "تعديل",
    "delete_btn": "حذف",
    "confirm_btn": "تأكيد",
    "no_profiles_row": "ما عندك بروفايلات محفوظة",
    "save_hint": "احفظ واحد بـ /save_pr",
    "ns_title": "السيرفرات الجديدة",
    "ns_label": "تطبيق بروفايل تلقائياً عند دخول سيرفر جديد",
    "ns_sub": "ما حددت شي = يختار من كل بروفايلاتك",
    "ns_applied": "سيرفر جديد: طبّقت {n}",
    "with_notes": " (مع ملاحظات)",
    "ns_fail": "فشل تطبيق بروفايل السيرفر الجديد",
    "save_fail": "تعذّر الحفظ",
    "need_server": "ادخل سيرفر أول.",
    "close": "إغلاق",
    "list_none": "ما عندك بروفايلات محفوظة.",
    "list_head": "بروفايلاتك ({n}):",
    "lang_title": "اللغة",
    "lang_note": "أوصاف أوامر / تتحدّث بعد إعادة تشغيل التطبيق",
    "cmd_pending": "⏳ لم يبدأ التسجيل",
    "cmd_search": "⏳ أدوّر على getBuiltInCommands",
    "cmd_ok": "✅ الأوامر مسجّلة ({n}) عبر getBuiltInCommands",
    "c_save": "احفظ بروفايل السيرفر الحالي",
    "o_name": "اسم البروفايل",
    "c_set": "طبّق بروفايل محفوظ (بدون اسم = يعرض القائمة)",
    "c_show": "اعرض بروفايلاتك كقائمة",
    "c_edit": "عدّل بروفايل محفوظ (الاسم المحفوظ أو الاسم المعروض)",
    "o_newname": "اسم البروفايل الجديد",
    "o_display": "الاسم المعروض (اكتب - للمسح)",
    "edited": "تم تعديل **{n}** ✅",
    "c_rename": "غيّر اسم بروفايل محفوظ",
    "o_cur": "الاسم الحالي",
    "o_new": "الاسم الجديد",
    "e_typenew": "اكتب الاسم الجديد",
    "renamed": "تم تغيير الاسم من **{a}** إلى **{b}** ✅",
    "c_delete": "احذف بروفايل محفوظ",
    "deleted": "تم حذف **{n}** 🗑️",
    "c_steal": "خذ بروفايل شخص ثاني",
    "o_user": "الشخص",
    "o_saveas": "اسم تحفظه به (اختياري)",
    "o_applynow": "طبّقه مباشرة",
    "c_key": "شارك بروفايلاتك بمفتاح: take key لأخذ مفتاح، Insert the key لإدخال مفتاح",
    "o_action": "اختر العملية",
    "o_key": "المفتاح أو جزء منه (مع Insert the key)",
    "o_keyname": "اسم بروفايل واحد (مع take key، فاضي = كل بروفايلاتك)",
    "e_pastekey": "الصق المفتاح (أو الجزء) في خيار key",
    "c_random": "طبّق بروفايل عشوائي من بروفايلاتك",
    "c_ns": "اختيار بروفايل تلقائياً عند دخول سيرفر جديد (الاختيار من الإعدادات)",
    "o_mode": "on للتشغيل، off للإيقاف",
    "ns_on": "تم تشغيل البروفايل التلقائي للسيرفرات الجديدة ✅",
    "ns_off": "تم إيقاف البروفايل التلقائي ⏹️"
  } };
  Object.assign(STR.en, {
    "card_colors": "Colors",
    "card_effect": "Effect",
    "card_deco": "Decoration",
    "card_ns": "Name style",
    "card_font": "Font {id}",
    "card_fx": "Effect {id}",
    "fav_group": "★ Favorites",
    "fav_short": "Favorites",
    "unfiled": "Unfiled",
    "all_f": "All",
    "folders_title": "Folders",
    "new_folder": "New folder name",
    "create_btn": "Create",
    "folder_count": "{n} profile(s)",
    "no_folders": "No folders yet",
    "folder_label": "Folder (empty = none)",
    "folder_ph": "e.g. Work",
    "no_folder": "None",
    "fav_on": "★ Favorite",
    "fav_off": "☆ Favorite",
    "no_match": "No profiles here",
    "fav_added": "Added {n} to favorites ★",
    "fav_removed": "Removed {n} from favorites",
    "folder_set": "Moved {n} to folder {f} 📁",
    "folder_cleared": "Removed {n} from its folder",
    "folder_made": "Folder {f} created 📁",
    "folder_deleted": "Folder {f} deleted (profiles kept)",
    "c_fav": "Add or remove a profile from favorites",
    "c_folder": "Move a profile to a folder",
    "o_folder": "Folder name (type - to remove from its folder)",
    "bk_title": "Backup Manager",
    "bk_auto_label": "Automatic backup",
    "bk_auto_sub": "Saves your profiles to a file on this device after every change, and restores them if the plugin comes back empty (e.g. after reinstalling)",
    "bk_nofs": "Device storage isn't available here, so backups can't be saved. Use Keys to export your profiles instead.",
    "bk_nofs_short": "Device storage isn't available",
    "bk_create": "Create backup now",
    "bk_created": "Backup created ({n} profiles) ✅",
    "bk_empty": "No backups yet",
    "bk_item_auto": "Automatic backup",
    "bk_item_manual": "Manual backup",
    "bk_sub": "{c} profile(s) • {kb} KB • {d}",
    "bk_restore": "Restore",
    "bk_merge": "Merge",
    "bk_delete": "Delete",
    "bk_confirm": "Confirm",
    "bk_restored": "Restored {c} profile(s) from backup ✅",
    "bk_merged": "Merged backup: {a} added, {s} already existed ✅",
    "bk_deleted": "Backup deleted",
    "bk_autorestored": "Restored {c} profile(s) from your saved backup",
    "bk_read_fail": "Couldn't read that backup",
    "bk_write_fail": "Couldn't write the backup file",
    "bk_none_to_save": "Nothing to back up yet",
    "bk_hint": "Restore replaces all current profiles. Merge only adds the missing ones.",
    "c_backup": "Back up or restore your profiles",
    "o_bk_action": "What to do",
    "e_nobackup": "No backups found",
    "bk_list_head": "Backups ({n}):"
  });
  Object.assign(STR.ar, {
    "card_colors": "الألوان",
    "card_effect": "الافكت",
    "card_deco": "الديكوريشن",
    "card_ns": "ستايل الاسم",
    "card_font": "خط {id}",
    "card_fx": "تأثير {id}",
    "fav_group": "★ المفضلة",
    "fav_short": "المفضلة",
    "unfiled": "بدون مجلد",
    "all_f": "الكل",
    "folders_title": "المجلدات",
    "new_folder": "اسم المجلد الجديد",
    "create_btn": "إنشاء",
    "folder_count": "{n} بروفايل",
    "no_folders": "ما فيه مجلدات",
    "folder_label": "المجلد (فاضي = بدون)",
    "folder_ph": "مثلاً: شغل",
    "no_folder": "بدون",
    "fav_on": "★ مفضّل",
    "fav_off": "☆ مفضّل",
    "no_match": "ما فيه بروفايلات هنا",
    "fav_added": "أضفت {n} للمفضلة ★",
    "fav_removed": "شلت {n} من المفضلة",
    "folder_set": "نقلت {n} إلى مجلد {f} 📁",
    "folder_cleared": "شلت {n} من مجلده",
    "folder_made": "تم إنشاء مجلد {f} 📁",
    "folder_deleted": "تم حذف مجلد {f} (البروفايلات باقية)",
    "c_fav": "أضف أو شل بروفايل من المفضلة",
    "c_folder": "انقل بروفايل إلى مجلد",
    "o_folder": "اسم المجلد (اكتب - لإزالته من مجلده)",
    "bk_title": "مدير النسخ الاحتياطي",
    "bk_auto_label": "نسخ احتياطي تلقائي",
    "bk_auto_sub": "يحفظ بروفايلاتك في ملف على الجهاز بعد كل تغيير، ويرجعها لو رجع البلوقن فاضي (مثلاً بعد حذفه وتحميله من جديد)",
    "bk_nofs": "تخزين الجهاز غير متوفر هنا، فما يمكن حفظ نسخ احتياطية. استخدم المفاتيح لتصدير بروفايلاتك.",
    "bk_nofs_short": "تخزين الجهاز غير متوفر",
    "bk_create": "أنشئ نسخة احتياطية الحين",
    "bk_created": "تم إنشاء النسخة ({n} بروفايل) ✅",
    "bk_empty": "ما فيه نسخ احتياطية",
    "bk_item_auto": "نسخة تلقائية",
    "bk_item_manual": "نسخة يدوية",
    "bk_sub": "{c} بروفايل • {kb} كب • {d}",
    "bk_restore": "استرجاع",
    "bk_merge": "دمج",
    "bk_delete": "حذف",
    "bk_confirm": "تأكيد",
    "bk_restored": "تم استرجاع {c} بروفايل من النسخة ✅",
    "bk_merged": "تم الدمج: أضفت {a} وتخطيت {s} موجودة ✅",
    "bk_deleted": "تم حذف النسخة",
    "bk_autorestored": "تم استرجاع {c} بروفايل من نسختك المحفوظة",
    "bk_read_fail": "تعذّرت قراءة النسخة",
    "bk_write_fail": "تعذّر كتابة ملف النسخة",
    "bk_none_to_save": "ما فيه شي تنسخه",
    "bk_hint": "الاسترجاع يستبدل كل بروفايلاتك الحالية، والدمج يضيف الناقص فقط.",
    "c_backup": "انسخ أو استرجع بروفايلاتك",
    "o_bk_action": "العملية",
    "e_nobackup": "ما لقيت نسخ احتياطية",
    "bk_list_head": "النسخ ({n}):"
  });
  var lang = function () { return getState().lang === "ar" ? "ar" : "en"; };
  var t = function (key, vars) {
    var d = STR[lang()];
    var str = d && d[key] !== undefined ? d[key] : STR.en[key] !== undefined ? STR.en[key] : key;
    if (vars) Object.keys(vars).forEach(function (n) { str = str.split("{" + n + "}").join(String(vars[n])); });
    return str;
  };

  // ===== أدوات =====
  var toast = function (t) {
    safe(function () {
      Toast.open("per-profile", { text: String(t).slice(0, 120) });
    });
  };

  var errText = function (err) {
    try {
      var b = (err && err.body) || err;
      return (((err && err.status) || "") + " " + (JSON.stringify(b) || (err && err.message) || err)).slice(0, 400);
    } catch (_) {
      return String(err);
    }
  };

  var clean = function (o) {
    var out = {};
    Object.keys(o).forEach(function (k) {
      if (o[k] !== null && o[k] !== undefined) out[k] = o[k];
    });
    return out;
  };

  var ext = function (hash) { return String(hash).indexOf("a_") === 0 ? "gif" : "png"; };

  var toDataURI = async function (url) {
    var blob = await (await fetch(url)).blob();
    return await new Promise(function (res, rej) {
      var r = new FileReader();
      r.onloadend = function () { res(r.result); };
      r.onerror = rej;
      r.readAsDataURL(blob);
    });
  };

  var currentGuildId = function () {
    return safe(function () { return Stores.SelectedGuildStore.getGuildId(); });
  };
  var me = function () { return Stores.UserStore.getCurrentUser(); };

  var fetchProfile = function (userId, guildId) {
    return HTTP.get({
      url: "/users/" + userId + "/profile?with_mutual_guilds=false&guild_id=" + guildId,
    });
  };

  // ===== قراءة البيانات =====
  var effId = function (x) {
    return x ? (x.sku_id != null ? x.sku_id : x.skuId != null ? x.skuId : x.id != null ? x.id : null) : null;
  };

  var readEffect = function (body) {
    var p = body.guild_member_profile || {};
    var up = body.user_profile || {};
    var r = effId(p.profile_effect);
    if (r == null) r = p.profile_effect_id;
    if (r == null) r = effId(up.profile_effect);
    if (r == null) r = up.profile_effect_id;
    return r == null ? null : r;
  };

  var readGuildDecoration = function (body) {
    var src = body.guild_member && body.guild_member.avatar_decoration_data;
    if (!src || !src.asset) return null;
    return { asset: src.asset, sku_id: src.sku_id != null ? src.sku_id : src.skuId != null ? src.skuId : null };
  };

  var readNameStyle = function (body) {
    var pick = function (s) {
      if (!s || typeof s !== "object") return null;
      var has = s.font_id != null || s.effect_id != null || (Array.isArray(s.colors) && s.colors.length > 0);
      return has ? s : null;
    };
    return pick(body.guild_member && body.guild_member.display_name_styles) ||
      pick(body.user && body.user.display_name_styles) || null;
  };

  var sameStyle = function (a, b) {
    var n = function (s) {
      return JSON.stringify([s && s.font_id != null ? s.font_id : null, s && s.effect_id != null ? s.effect_id : null, (s && s.colors) || []]);
    };
    return n(a) === n(b);
  };

  var buildData = async function (body, userId, guildId, withNick) {
    var p = body.guild_member_profile || {};
    var m = body.guild_member || {};
    var u = body.user || {};
    var up = body.user_profile || {};

    var avatarUrl = null;
    var avatarSrc = t("av_none");
    var cu = safe(function () { return Stores.UserStore.getUser(userId); });
    var avatarHash = u.avatar || (cu && cu.avatar);
    if (m.avatar) {
      avatarUrl = "https://cdn.discordapp.com/guilds/" + guildId + "/users/" + userId + "/avatars/" + m.avatar + "." + ext(m.avatar) + "?size=1024";
      avatarSrc = t("av_guild");
    } else if (avatarHash) {
      avatarUrl = "https://cdn.discordapp.com/avatars/" + userId + "/" + avatarHash + "." + ext(avatarHash) + "?size=1024";
      avatarSrc = t("av_global");
    }

    var bannerUrl = null;
    if (p.banner) {
      bannerUrl = "https://cdn.discordapp.com/guilds/" + guildId + "/users/" + userId + "/banners/" + p.banner + "." + ext(p.banner) + "?size=1024";
    } else if (u.banner || up.banner) {
      var bh = u.banner || up.banner;
      bannerUrl = "https://cdn.discordapp.com/banners/" + userId + "/" + bh + "." + ext(bh) + "?size=1024";
    }

    var pick = function (a, b) { return a != null ? a : b; };
    var data = {
      bio: pick(p.bio, pick(up.bio, "")),
      pronouns: pick(p.pronouns, pick(up.pronouns, "")),
      accent_color: pick(p.accent_color, pick(up.accent_color, pick(u.accent_color, null))),
      theme_colors: pick(p.theme_colors, pick(up.theme_colors, null)),
      profile_effect_id: readEffect(body),
      avatar_decoration: readGuildDecoration(body),
      display_name_styles: readNameStyle(body),
      nick: withNick ? (m.nick != null ? m.nick : null) : null,
      avatarUrl: avatarUrl,
      bannerUrl: bannerUrl,
      avatar: avatarUrl ? await toDataURI(avatarUrl) : null,
      banner: bannerUrl ? await toDataURI(bannerUrl) : null,
    };
    return { data: data, avatarSrc: avatarSrc };
  };

  var summary = function (d) {
    return [
      d.avatar ? t("s_avatar") : null,
      d.banner ? t("s_banner") : null,
      d.profile_effect_id ? t("s_effect") : null,
      d.avatar_decoration ? t("s_deco") : null,
      d.display_name_styles ? t("s_namestyle") : null,
      d.bio ? t("s_bio") : null,
      d.nick ? t("s_nick", { v: d.nick }) : null,
    ].filter(Boolean).join(" • ") || t("s_empty");
  };

  // ===== التطبيق =====
  var applyProfile = async function (d, guildId) {
    var notes = [];
    var meId = me().id;

    if (d.nick) {
      try {
        await HTTP.patch({ url: "/guilds/" + guildId + "/members/@me", body: { nick: d.nick } });
      } catch (err) {
        if (!(err && err.body && err.body.code === 50013)) notes.push(t("n_nick", { e: errText(err) }));
      }
    }

    if (d.avatar) {
      try {
        await HTTP.patch({ url: "/guilds/" + guildId + "/members/@me", body: { avatar: d.avatar } });
      } catch (err) {
        notes.push(
          JSON.stringify((err && err.body) || "").indexOf("AVATAR_RATE_LIMIT") >= 0
            ? t("n_avatar_rl")
            : t("n_avatar", { e: errText(err) })
        );
      }
    }

    if (d.display_name_styles) {
      var st = d.display_name_styles;
      try {
        await HTTP.patch({
          url: "/guilds/" + guildId + "/members/@me",
          body: clean({
            display_name_font_id: st.font_id,
            display_name_effect_id: st.effect_id,
            display_name_colors: st.colors,
          }),
        });
        var r1 = await fetchProfile(meId, guildId);
        if (!sameStyle(readNameStyle(r1.body), st)) notes.push(t("n_ns_nochange"));
      } catch (err) {
        notes.push(t("n_ns_err", { e: errText(err) }));
      }
    }

    try {
      await HTTP.patch({
        url: "/guilds/" + guildId + "/profile/@me",
        body: clean({
          bio: d.bio,
          pronouns: d.pronouns,
          banner: d.banner,
          accent_color: d.accent_color,
          theme_colors: d.theme_colors,
        }),
      });
    } catch (err) {
      notes.push(t("n_bbb", { e: errText(err) }));
    }

    if (d.profile_effect_id) {
      try {
        await HTTP.patch({
          url: "/guilds/" + guildId + "/profile/@me",
          body: { collectibles_sku_ids: [String(d.profile_effect_id)] },
        });
        var r2 = await fetchProfile(meId, guildId);
        var got = readEffect(r2.body);
        if (String(got) !== String(d.profile_effect_id)) notes.push(t("n_eff_nochange", { v: got != null ? got : t("none_word") }));
      } catch (err) {
        notes.push(t("n_eff_err", { e: errText(err) }));
      }
    }

    if (d.avatar_decoration && d.avatar_decoration.asset) {
      var dec = d.avatar_decoration;
      var ids = [dec.sku_id, d.profile_effect_id].filter(Boolean).map(String);
      var attempts = [];
      if (dec.sku_id) attempts.push({ url: "/guilds/" + guildId + "/profile/@me", body: { collectibles_sku_ids: ids } });
      attempts.push(
        { url: "/guilds/" + guildId + "/members/@me", body: { avatar_decoration_id: dec.sku_id != null ? dec.sku_id : dec.asset, avatar_decoration_sku_id: dec.sku_id } },
        { url: "/guilds/" + guildId + "/members/@me", body: { avatar_decoration_data: { asset: dec.asset, sku_id: dec.sku_id } } },
        { url: "/guilds/" + guildId + "/profile/@me", body: { avatar_decoration_data: { asset: dec.asset, sku_id: dec.sku_id } } }
      );
      var done = false;
      var lastErr = null;
      for (var i = 0; i < attempts.length; i++) {
        try {
          await HTTP.patch({ url: attempts[i].url, body: clean(attempts[i].body) });
          var r3 = await fetchProfile(meId, guildId);
          var gd = readGuildDecoration(r3.body);
          if (gd && gd.asset === dec.asset) { done = true; break; }
        } catch (err) {
          lastErr = err;
        }
      }
      if (!done) notes.push(t("n_deco_fail") + (lastErr ? ": " + errText(lastErr) : ""));
    }

    return notes;
  };

  const PROFILES = function () { return getState().profiles; };
  const SAVE = function (n, d) {
    var p = Object.assign({}, getState().profiles);
    p[n] = d;
    setState({ profiles: p });
  };
  const copyText = function (t) {
    return safe(function () { V.externals.ReactNativeClipboard.Clipboard.setString(t); return true; }, false);
  };

  // ===== المفاتيح (مشاركة البروفايلات) =====
  // المفتاح = JSON مضغوط (LZW) ثم base64 ثم مقسوم لأجزاء كل جزء أقل من 2000 حرف
  const utf8Bytes = (str) => {
    const enc = encodeURIComponent(str);
    const out = [];
    for (let i = 0; i < enc.length; i++) {
      if (enc[i] === "%") {
        out.push(parseInt(enc.substr(i + 1, 2), 16));
        i += 2;
      } else out.push(enc.charCodeAt(i));
    }
    return out;
  };
  const bytesUtf8 = (bytes) => {
    let s = "";
    for (const b of bytes) s += "%" + ("0" + b.toString(16)).slice(-2);
    return decodeURIComponent(s);
  };
  const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const b64FromBytes = (bytes) => {
    let out = "";
    for (let j = 0; j < bytes.length; j += 3) {
      const a = bytes[j], b = bytes[j + 1], c = bytes[j + 2];
      out +=
        B64[a >> 2] +
        B64[((a & 3) << 4) | ((b || 0) >> 4)] +
        (b === undefined ? "=" : B64[((b & 15) << 2) | ((c || 0) >> 6)]) +
        (c === undefined ? "=" : B64[c & 63]);
    }
    return out;
  };
  const b64ToBytes = (str) => {
    str = str.replace(/[^A-Za-z0-9+\/]/g, "");
    const bytes = [];
    let buf = 0, bits = 0;
    for (let i = 0; i < str.length; i++) {
      buf = (buf << 6) | B64.indexOf(str[i]);
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        bytes.push((buf >> bits) & 255);
        buf &= (1 << bits) - 1;
      }
    }
    return bytes;
  };

  const lzwEnc = (bytes) => {
    const dict = new Map();
    let size = 256;
    let w = "";
    const out = [];
    const code = (s) => (s.length === 1 ? s.charCodeAt(0) : dict.get(s));
    for (const b of bytes) {
      const c = String.fromCharCode(b);
      const wc = w + c;
      if (wc.length === 1 || dict.has(wc)) w = wc;
      else {
        out.push(code(w));
        if (size < 4096) dict.set(wc, size++);
        w = c;
      }
    }
    if (w) out.push(code(w));
    return out;
  };
  const lzwDec = (codes) => {
    if (!codes.length) return [];
    const dict = [];
    for (let i = 0; i < 256; i++) dict[i] = String.fromCharCode(i);
    let size = 256;
    let w = dict[codes[0]];
    const out = [w];
    for (let i = 1; i < codes.length; i++) {
      const k = codes[i];
      let entry;
      if (dict[k] !== undefined) entry = dict[k];
      else if (k === size) entry = w + w[0];
      else throw new Error("bad lzw");
      out.push(entry);
      if (size < 4096) dict[size++] = w + entry[0];
      w = entry;
    }
    const s = out.join("");
    const bytes = [];
    for (let i = 0; i < s.length; i++) bytes.push(s.charCodeAt(i));
    return bytes;
  };
  const packCodes = (codes) => {
    const n = codes.length;
    const bytes = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    for (let i = 0; i < n; i += 2) {
      const a = codes[i];
      const b = i + 1 < n ? codes[i + 1] : 0;
      bytes.push(a >> 4, ((a & 15) << 4) | (b >> 8), b & 255);
    }
    return bytes;
  };
  const unpackCodes = (bytes) => {
    const n = (bytes[0] << 16) | (bytes[1] << 8) | bytes[2];
    const codes = [];
    for (let i = 3; i < bytes.length && codes.length < n; i += 3) {
      const x = bytes[i], y = bytes[i + 1] || 0, z = bytes[i + 2] || 0;
      codes.push((x << 4) | (y >> 4));
      if (codes.length < n) codes.push(((y & 15) << 8) | z);
    }
    return codes;
  };

  const shortUrl = (u) =>
    typeof u === "string" ? u.replace(/^https:\/\/cdn\.discordapp\.com\//, "").replace(/\?size=1024$/, "") : u;
  const longUrl = (u) =>
    typeof u === "string" && !/^https?:/.test(u) ? "https://cdn.discordapp.com/" + u + "?size=1024" : u;

  const PART_SIZE = 1850;

  const makeKey = (name) => {
    const all = PROFILES();
    const names = name ? [name] : Object.keys(all);
    if (!names.length) throw new Error(t("e_nopro"));
    const pack = {};
    let noImg = 0;
    for (const n of names) {
      const d = all[n];
      if (!d) throw new Error(t("e_nf", { n: n }));
      const o = {};
      for (const k of Object.keys(d)) {
        if (k === "avatar" || k === "banner" || k === "fav" || k === "folder") continue;
        const v = d[k];
        if (v === null || v === undefined || v === "" || (Array.isArray(v) && !v.length)) continue;
        o[k] = k === "avatarUrl" || k === "bannerUrl" ? shortUrl(v) : v;
      }
      if ((d.avatar && !d.avatarUrl) || (d.banner && !d.bannerUrl)) noImg++;
      pack[n] = o;
    }
    const payload = b64FromBytes(packCodes(lzwEnc(utf8Bytes(JSON.stringify({ v: 2, p: pack })))));
    const id = Math.random().toString(36).slice(2, 6);
    const total = Math.max(1, Math.ceil(payload.length / PART_SIZE));
    const parts = [];
    for (let i = 0; i < total; i++) {
      parts.push(`PP2.${id}.${i + 1}.${total}:` + payload.slice(i * PART_SIZE, (i + 1) * PART_SIZE));
    }
    return { parts, count: names.length, noImg };
  };

  const importObj = async (obj) => {
    if (!obj || !obj.p || typeof obj.p !== "object") throw new Error(t("e_keyempty"));
    const added = [];
    const notes = [];
    for (const n of Object.keys(obj.p)) {
      const d = { ...obj.p[n] };
      if (d.avatarUrl) d.avatarUrl = longUrl(d.avatarUrl);
      if (d.bannerUrl) d.bannerUrl = longUrl(d.bannerUrl);
      let finalName = n;
      let c = 2;
      while (PROFILES()[finalName]) finalName = `${n} (${c++})`;
      try {
        if (d.avatarUrl) d.avatar = await toDataURI(d.avatarUrl);
      } catch {
        notes.push(t("img_av_fail", { n: finalName }));
      }
      try {
        if (d.bannerUrl) d.banner = await toDataURI(d.bannerUrl);
      } catch {
        notes.push(t("img_bn_fail", { n: finalName }));
      }
      SAVE(finalName, d);
      added.push(finalName);
    }
    return t("k_added", { c: added.length, names: added.join(t("list_sep")) }) + (notes.length ? "\n" + notes.join("\n") : "");
  };

  const pendingKeys = {};

  // يقبل جزء أو أكثر (مفصولة بمسافة أو سطر)، ويستورد لما تكتمل كل الأجزاء
  const feedKeys = async (input) => {
    const text = String(input || "");
    const re2 = /PP2\.([A-Za-z0-9]{3,8})\.(\d+)\.(\d+):((?:(?!PP2\.[A-Za-z0-9]{3,8}\.\d+\.\d+:)[A-Za-z0-9+\/=])+)/g;
    const lines = [];
    const touched = [];
    let found = false;
    let m;
    while ((m = re2.exec(text))) {
      found = true;
      const id = m[1];
      if (!pendingKeys[id]) pendingKeys[id] = { n: parseInt(m[3], 10), parts: {} };
      pendingKeys[id].parts[parseInt(m[2], 10)] = m[4];
      if (touched.indexOf(id) < 0) touched.push(id);
    }
    for (const id of touched) {
      const p = pendingKeys[id];
      const missing = [];
      for (let i = 1; i <= p.n; i++) if (!p.parts[i]) missing.push(i);
      if (missing.length) {
        lines.push(t("k_missing", { have: p.n - missing.length, n: p.n, miss: missing.join(t("list_sep")) }));
        continue;
      }
      let payload = "";
      for (let i = 1; i <= p.n; i++) payload += p.parts[i];
      delete pendingKeys[id];
      let obj;
      try {
        obj = JSON.parse(bytesUtf8(lzwDec(unpackCodes(b64ToBytes(payload)))));
      } catch {
        lines.push(t("k_corrupt"));
        continue;
      }
      lines.push(await importObj(obj));
    }
    const m1 = text.match(/PP1:([A-Za-z0-9+\/=]+)/);
    if (m1) {
      found = true;
      let obj;
      try {
        obj = JSON.parse(bytesUtf8(b64ToBytes(m1[1])));
      } catch {
        throw new Error(t("k_old_corrupt"));
      }
      lines.push(await importObj(obj));
    }
    if (!found) throw new Error(t("k_notfound"));
    return lines.join("\n");
  };

  const keyTakeText = (r) =>
    t(r.parts.length > 1 ? "k_take_many" : "k_take_one", { count: r.count, parts: r.parts.length }) +
    (r.noImg ? "\n" + t("k_noimg", { n: r.noImg }) : "");

  // ===== العمليات =====
  var requireGuild = function () {
    var g = currentGuildId();
    if (!g) throw new Error(t("e_needguild"));
    return g;
  };

  var saveCurrent = async function (name) {
    var guildId = requireGuild();
    var meId = me().id;
    var res = await fetchProfile(meId, guildId);
    var out = await buildData(res.body, meId, guildId, true);
    var profiles = Object.assign({}, getState().profiles);
    profiles[name] = out.data;
    setState({ profiles: profiles });
    return t("saved", { name: name, src: out.avatarSrc });
  };

  var stealUser = async function (userId, name, applyNow) {
    var guildId = requireGuild();
    var cu = safe(function () { return Stores.UserStore.getUser(userId); });
    var finalName = name || (cu && cu.username) || userId;
    var res = await fetchProfile(userId, guildId);
    var out = await buildData(res.body, userId, guildId, false);
    var profiles = Object.assign({}, getState().profiles);
    profiles[finalName] = out.data;
    setState({ profiles: profiles });
    var text = t("stole", { name: finalName });
    if (applyNow) {
      var notes = await applyProfile(out.data, guildId);
      text += "\n" + t("applied_now") + (notes.length ? "\n" + notes.join("\n") : " ✅");
    }
    return text;
  };

  var applyByName = async function (name) {
    var guildId = requireGuild();
    var d = getState().profiles[name];
    if (!d) throw new Error(t("e_nf", { n: name }));
    var notes = await applyProfile(d, guildId);
    return t("applied", { name: name }) + (notes.length ? "\n" + notes.join("\n") : " ✅");
  };

  var applyRandom = async function () {
    var names = Object.keys(getState().profiles);
    if (!names.length) throw new Error(t("e_nopro"));
    var name = names[Math.floor(Math.random() * names.length)];
    return "🎲 " + (await applyByName(name));
  };

  var renameProfile = function (oldName, newName, nick) {
    var s = getState();
    var profiles = Object.assign({}, s.profiles);
    var ns = Object.assign({}, s.ns);
    if (newName !== oldName) {
      if (profiles[newName]) throw new Error(t("e_dupname"));
      profiles[newName] = profiles[oldName];
      delete profiles[oldName];
      ns.names = (ns.names || []).map(function (n) { return n === oldName ? newName : n; });
    }
    profiles[newName] = Object.assign({}, profiles[newName], { nick: nick || null });
    setState({ profiles: profiles, ns: ns });
  };

  var deleteProfile = function (name) {
    var s = getState();
    var profiles = Object.assign({}, s.profiles);
    delete profiles[name];
    setState({
      profiles: profiles,
      ns: Object.assign({}, s.ns, { names: (s.ns.names || []).filter(function (n) { return n !== name; }) }),
    });
  };

  // ===== شاشة الإعدادات =====
  function SettingsComponent(props) {
    var U0;
    try { U0 = ui(); } catch (err) { return null; }
    var need = ["Stack", "TableRowGroup", "TableRow", "TableSwitchRow", "TextInput", "Button"];
    var miss = need.filter(function (n) { return !U0.D[n]; });
    ["View", "Text", "ScrollView"].forEach(function (n) { if (!U0.RN[n]) miss.push("RN." + n); });
    if (miss.length) {
      if (!U0.RN.Text) return null;
      return U0.R.createElement(U0.RN.Text, { style: { color: "#ffffff", padding: 16 } },
        "Per Profile: missing UI components: " + miss.join(", ") + "\ndesign keys: " + Object.keys(U0.D).slice(0, 40).join(", "));
    }
    return U0.R.createElement(SettingsInner, props);
  }

  function SettingsInner(props) {
    var U = ui();
    var R = U.R, RN = U.RN, D = U.D;
    var h = R.createElement;
    var storage = props.api.jsonStorage;
    var st = Object.assign({}, DEFAULTS, storage.use());
    st.profiles = st.profiles || {};
    st.ns = Object.assign({}, DEFAULTS.ns, st.ns || {});
    store = storage;
    mirror = st;

    var nameS = R.useState(""); var name = nameS[0], setName = nameS[1];
    var userS = R.useState(""); var userId = userS[0], setUserId = userS[1];
    var logS = R.useState(""); var log = logS[0], setLog = logS[1];
    var busyS = R.useState(false); var busy = busyS[0], setBusy = busyS[1];
    var editS = R.useState(null); var editing = editS[0], setEditing = editS[1];
    var enS = R.useState(""); var editName = enS[0], setEditName = enS[1];
    var ekS = R.useState(""); var editNick = ekS[0], setEditNick = ekS[1];
    var delS = R.useState(null); var confirmDel = delS[0], setConfirmDel = delS[1];
    var tkS = R.useState(0); var setTick = tkS[1];
    var knS = R.useState(""); var keyName = knS[0], setKeyName = knS[1];
    var koS = R.useState([]); var keyOut = koS[0], setKeyOut = koS[1];
    var kiS = R.useState(""); var keyIn = kiS[0], setKeyIn = kiS[1];
    var efS = R.useState(""); var editFolder = efS[0], setEditFolder = efS[1];
    var nfS = R.useState(""); var newFolder = nfS[0], setNewFolder = nfS[1];
    var dfS = R.useState(null); var confirmFolder = dfS[0], setConfirmFolder = dfS[1];
    var bkS = R.useState({ items: [], fs: true }); var bk = bkS[0], setBk = bkS[1];
    var bcS = R.useState(null); var bkConfirm = bcS[0], setBkConfirm = bcS[1];
    var refreshBk = function () {
      readIndex().then(function (idx) { setBk({ items: idx.items, fs: !!getFM() }); }, function () {});
    };
    R.useEffect(function () { refreshBk(); }, []);

    var run = async function (fn) {
      if (busy) return;
      setBusy(true);
      try {
        var res = await fn();
        if (res) { setLog(String(res)); toast(String(res).split("\n")[0]); }
      } catch (err) {
        var m = t("err_prefix") + ((err && err.message) || errText(err));
        setLog(m);
        toast(m);
      } finally {
        setBusy(false);
      }
    };

    var names = Object.keys(st.profiles);
    var Btn = function (key, text, onPress) {
      return h(D.Button, { key: key, text: text, size: "sm", onPress: onPress });
    };

    var profileRow = function (n) {
      var d = st.profiles[n];
      var fo = folderOf(d);
      return h(D.TableRow, {
        key: "p-" + n,
        label: (isFav(d) ? "★ " : "") + n,
        subLabel: (isFav(d) && fo ? "📁 " + fo + " • " : "") + summary(d),
        trailing: h(RN.View, { style: { flexDirection: "row" } }, [
          Btn("s", isFav(d) ? "★" : "☆", function () { try { toggleFav(n); } catch (err) { toast(err.message); } }),
          Btn("a", t("apply_btn"), function () { run(function () { return applyByName(n); }); }),
          Btn("e", t("edit_btn"), function () {
            setEditing(n); setEditName(n); setEditNick(d.nick || ""); setEditFolder(fo); setConfirmDel(null);
          }),
          Btn("d", confirmDel === n ? t("confirm_btn") : t("delete_btn"), function () {
            if (confirmDel !== n) return setConfirmDel(n);
            deleteProfile(n); setConfirmDel(null);
            if (editing === n) setEditing(null);
          }),
        ]),
      });
    };
    var profileGroups = function () {
      var groups = [];
      var favs = names.filter(function (n) { return isFav(st.profiles[n]); });
      if (favs.length) groups.push(h(D.TableRowGroup, { key: "g-fav", title: t("fav_group") + " (" + favs.length + ")" }, favs.map(profileRow)));
      allFolders().forEach(function (f) {
        var l = names.filter(function (n) { return !isFav(st.profiles[n]) && folderOf(st.profiles[n]) === f; });
        if (l.length) groups.push(h(D.TableRowGroup, { key: "g-" + f, title: "📁 " + f + " (" + l.length + ")" }, l.map(profileRow)));
      });
      var un = names.filter(function (n) { return !isFav(st.profiles[n]) && !folderOf(st.profiles[n]); });
      if (un.length) groups.push(h(D.TableRowGroup, { key: "g-un", title: (groups.length ? t("unfiled") : t("your_profiles", { n: names.length })) + " (" + un.length + ")" }, un.map(profileRow)));
      return groups;
    };

    var body = h(D.Stack, { spacing: 24 }, [
      h(D.TableRowGroup, { key: "lang", title: t("lang_title") }, [
        h(D.TableRow, {
          key: "lang-row",
          label: lang() === "ar" ? "العربية" : "English",
          subLabel: t("lang_note"),
          trailing: h(RN.View, { style: { flexDirection: "row" } }, [
            Btn("en", (lang() === "en" ? "✓ " : "") + "English", function () { setState({ lang: "en" }); }),
            Btn("ar", (lang() === "ar" ? "✓ " : "") + "العربية", function () { setState({ lang: "ar" }); }),
          ]),
        }),
      ]),

      log ? h(D.TableRowGroup, { key: "log", title: t("last_result") }, h(D.TableRow, { label: log })) : null,

      h(D.TableRowGroup, { key: "cmd", title: t("cmd_status_title") }, [
        h(D.TableRow, { key: "cs", label: cmdText(), subLabel: diag() }),
      ]),
      h(D.Button, {
        key: "cmdRetry",
        text: t("re_register"),
        onPress: function () { if (retryCommands) retryCommands(); setTick(function (x) { return x + 1; }); },
      }),

      h(D.TableRowGroup, { key: "save", title: t("save_title") }, [
        h(D.TextInput, { key: "n", label: t("profile_name"), placeholder: t("profile_ph"), value: name, onChange: setName, isClearable: true }),
      ]),
      h(D.Button, {
        key: "saveBtn",
        text: busy ? t("busy") : t("save_cur"),
        onPress: function () {
          var n = name.trim();
          if (!n) return toast(t("type_name"));
          run(async function () { var t = await saveCurrent(n); setName(""); return t; });
        },
      }),

      h(D.TextInput, { key: "u", label: t("steal_label"), placeholder: "User ID", value: userId, onChange: setUserId, isClearable: true }),
      h(D.Button, {
        key: "stealBtn",
        text: t("steal_btn"),
        onPress: function () {
          var id = userId.trim();
          if (!id) return toast(t("type_id"));
          run(async function () { var t = await stealUser(id, name.trim() || null, false); setUserId(""); return t; });
        },
      }),

      h(D.Button, { key: "rnd", text: t("random_btn"), onPress: function () { run(applyRandom); } }),

      h(D.TableRowGroup, { key: "keysT", title: t("keys_title") }, [
        h(D.TableRow, { key: "kx", label: t("keys_row"), subLabel: t("keys_sub") }),
      ]),
      h(D.TextInput, { key: "kn", label: t("key_name_label"), value: keyName, onChange: setKeyName, isClearable: true }),
      h(D.Button, {
        key: "kTake",
        text: t("take_btn"),
        onPress: function () {
          try {
            var r = makeKey(keyName.trim() || null);
            setKeyOut(r.parts);
            var m = t("key_ready", { count: r.count, parts: r.parts.length }) +
              (r.noImg ? "\n" + t("k_noimg", { n: r.noImg }) : "");
            setLog(m); toast(m.split("\n")[0]);
          } catch (err) { toast(err.message); }
        },
      }),
      keyOut.length
        ? h(D.TableRowGroup, { key: "kp", title: t("parts_title", { n: keyOut.length }) },
            keyOut.map(function (part, i) {
              return h(D.TableRow, {
                key: "kp" + i,
                label: t("part_label", { i: i + 1, n: keyOut.length }),
                subLabel: t("chars", { n: part.length }),
                trailing: Btn("c" + i, t("copy"), function () { toast(copyText(part) ? t("copied", { i: i + 1 }) : t("copy_fail")); }),
              });
            }))
        : null,
      h(D.TextInput, { key: "ki", label: t("insert_label"), placeholder: "PP1:...", value: keyIn, onChange: setKeyIn, isClearable: true }),
      h(D.Button, {
        key: "kIns",
        text: "Insert the key",
        onPress: function () {
          var k = keyIn.trim();
          if (!k) return toast(t("paste_first"));
          run(async function () { var t = await feedKeys(k); setKeyIn(""); return t; });
        },
      }),

      editing && st.profiles[editing]
        ? h(D.TableRowGroup, { key: "edit", title: t("edit_title", { n: editing }) }, [
            h(D.TextInput, { key: "en", label: t("saved_name_label"), value: editName, onChange: setEditName }),
            h(D.TextInput, { key: "ek", label: t("display_label"), value: editNick, onChange: setEditNick }),
            h(D.TextInput, { key: "ef", label: t("folder_label"), placeholder: t("folder_ph"), value: editFolder, onChange: setEditFolder }),
            h(RN.View, { key: "eb", style: { flexDirection: "row", padding: 12 } }, [
              Btn("es", t("save_btn"), function () {
                try {
                  var nn = editName.trim();
                  if (!nn) return toast(t("name_empty"));
                  renameProfile(editing, nn, editNick.trim());
                  setFolderOf(nn, editFolder);
                  setEditing(null);
                  toast(t("edit_saved"));
                } catch (err) { toast(err.message); }
              }),
              Btn("ec", t("cancel"), function () { setEditing(null); }),
            ]),
          ])
        : null,

      names.length ? null : h(D.TableRowGroup, { key: "list0", title: t("your_profiles", { n: 0 }) }, h(D.TableRow, { label: t("no_profiles_row") })),
    ].concat(profileGroups()).concat([

      h(D.TableRowGroup, { key: "foldersT", title: t("folders_title") }, [
        h(D.TextInput, { key: "nf", label: t("new_folder"), placeholder: t("folder_ph"), value: newFolder, onChange: setNewFolder, isClearable: true }),
        h(RN.View, { key: "nfb", style: { flexDirection: "row", padding: 12 } }, [
          Btn("nfc", t("create_btn"), function () {
            var f = newFolder.trim();
            if (!f) return toast(t("name_empty"));
            addFolder(f); setNewFolder(""); toast(t("folder_made", { f: f }));
          }),
        ]),
      ].concat(
        allFolders().length
          ? allFolders().map(function (f) {
              var cnt = names.filter(function (n) { return folderOf(st.profiles[n]) === f; }).length;
              return h(D.TableRow, {
                key: "fo-" + f,
                label: "📁 " + f,
                subLabel: t("folder_count", { n: cnt }),
                trailing: Btn("fd", confirmFolder === f ? t("confirm_btn") : t("delete_btn"), function () {
                  if (confirmFolder !== f) return setConfirmFolder(f);
                  deleteFolder(f); setConfirmFolder(null); toast(t("folder_deleted", { f: f }));
                }),
              });
            })
          : [h(D.TableRow, { key: "nofo", label: t("no_folders") })]
      )),

      h(D.TableRowGroup, { key: "bkT", title: t("bk_title") }, [
        h(D.TableSwitchRow, {
          key: "bkAuto",
          label: t("bk_auto_label"),
          subLabel: bk.fs ? t("bk_auto_sub") : t("bk_nofs") + "\n" + fmDiag,
          value: st.autoBackup !== false,
          onValueChange: function (v) { setState({ autoBackup: v }); if (v) scheduleAuto(); },
        }),
        h(D.TableRow, { key: "bkHint", label: t("bk_hint") }),
      ].concat(
        bk.items.length
          ? bk.items.map(function (it) {
              return h(D.TableRow, {
                key: "bk-" + it.id,
                label: it.kind === "auto" ? t("bk_item_auto") : t("bk_item_manual"),
                subLabel: bkSub(it),
                trailing: h(RN.View, { style: { flexDirection: "row" } }, [
                  Btn("r", bkConfirm === it.id ? t("bk_confirm") : t("bk_restore"), function () {
                    if (bkConfirm !== it.id) return setBkConfirm(it.id);
                    setBkConfirm(null);
                    run(function () { return restoreBackup(it.id, "replace"); }).then(refreshBk);
                  }),
                  Btn("m", t("bk_merge"), function () { setBkConfirm(null); run(function () { return restoreBackup(it.id, "merge"); }); }),
                  Btn("x", t("bk_delete"), function () {
                    run(async function () { await deleteBackup(it.id); return t("bk_deleted"); }).then(refreshBk);
                  }),
                ]),
              });
            })
          : [h(D.TableRow, { key: "bkNone", label: t("bk_empty") })]
      )),
      h(D.Button, {
        key: "bkCreate",
        text: t("bk_create"),
        onPress: function () { run(createBackup).then(refreshBk); },
      }),

      h(D.TableRowGroup, { key: "ns", title: t("ns_title") },
        [h(D.TableSwitchRow, {
          key: "nsOn",
          label: t("ns_label"),
          subLabel: t("ns_sub"),
          value: !!st.ns.enabled,
          onValueChange: function (v) { setState({ ns: Object.assign({}, st.ns, { enabled: v }) }); },
        })].concat(
          names.map(function (n) {
            return h(D.TableSwitchRow, {
              key: "ns-" + n,
              label: n,
              value: st.ns.names.indexOf(n) >= 0,
              onValueChange: function (v) {
                var arr = st.ns.names.filter(function (x) { return x !== n; });
                if (v) arr.push(n);
                setState({ ns: Object.assign({}, st.ns, { names: arr }) });
              },
            });
          })
        )
      ),
    ]));

    var content = h(RN.ScrollView, { contentContainerStyle: { paddingBottom: 40 } }, body);
    return U.Page ? h(U.Page, null, content) : content;
  }

  // ===== السيرفر الجديد =====
  var knownGuilds = null;
  var onGuildCreate = function (ev) {
    try {
      var g = ev && ev.guild;
      var id = g && g.id;
      if (!id || !knownGuilds || knownGuilds.has(id)) return;
      knownGuilds.add(id);
      if (g.joined_at && Date.now() - new Date(g.joined_at).getTime() > 5 * 60 * 1000) return;
      var s = getState();
      if (!s.ns.enabled) return;
      var pool = (s.ns.names || []).filter(function (n) { return s.profiles[n]; });
      if (!pool.length) pool = Object.keys(s.profiles);
      if (!pool.length) return;
      var pn = pool[Math.floor(Math.random() * pool.length)];
      setTimeout(async function () {
        try {
          var notes = await applyProfile(s.profiles[pn], id);
          toast(t("ns_applied", { n: pn }) + (notes.length ? t("with_notes") : " ✅"));
        } catch (_) {
          toast(t("ns_fail"));
        }
      }, 3000);
    } catch (_) {}
  };


  // ===== Folders & Favorites =====
  var isFav = function (d) { return !!(d && d.fav); };
  var folderOf = function (d) { return d && d.folder ? String(d.folder) : ""; };
  var allFolders = function () {
    var s = getState();
    var out = (s.folders || []).slice();
    Object.keys(s.profiles).forEach(function (n) {
      var f = folderOf(s.profiles[n]);
      if (f && out.indexOf(f) < 0) out.push(f);
    });
    return out;
  };
  var patchProfile = function (name, patch, extra) {
    var s = getState();
    var p = Object.assign({}, s.profiles);
    if (!p[name]) throw new Error(t("e_nf", { n: name }));
    var o = Object.assign({}, p[name], patch);
    Object.keys(patch).forEach(function (k) {
      if (patch[k] === null || patch[k] === false || patch[k] === "") delete o[k];
    });
    p[name] = o;
    setState(Object.assign({ profiles: p }, extra || {}));
  };
  var toggleFav = function (name) {
    var v = !isFav(getState().profiles[name]);
    patchProfile(name, { fav: v });
    return v;
  };
  var setFolderOf = function (name, folder) {
    folder = folder ? String(folder).trim() : "";
    if (folder === "-") folder = "";
    var cur = getState().folders || [];
    var extra = folder && cur.indexOf(folder) < 0 ? { folders: cur.concat([folder]) } : {};
    patchProfile(name, { folder: folder || null }, extra);
    return folder;
  };
  var addFolder = function (f) {
    f = String(f || "").trim();
    if (!f) return false;
    var cur = getState().folders || [];
    if (cur.indexOf(f) < 0) setState({ folders: cur.concat([f]) });
    return true;
  };
  var deleteFolder = function (f) {
    var s = getState();
    var p = Object.assign({}, s.profiles);
    Object.keys(p).forEach(function (n) {
      if (folderOf(p[n]) === f) { p[n] = Object.assign({}, p[n]); delete p[n].folder; }
    });
    setState({ profiles: p, folders: (s.folders || []).filter(function (x) { return x !== f; }) });
  };
  var sortedNames = function (list) {
    var p = getState().profiles;
    var names = list || Object.keys(p);
    return names.filter(function (n) { return isFav(p[n]); }).concat(names.filter(function (n) { return !isFav(p[n]); }));
  };

  // ===== Backup Manager (ملفات على الجهاز، تبقى بعد حذف البلوقن) =====
  var fmCache = null;
  var fmDiag = "";
  var FM_NAMES = ["NativeFileModule", "DCDFileManager", "RTNFileManager", "RNFileManager", "FileManager", "RNFSManager", "RNFS", "ReactNativeFS"];
  var getFM = function () {
    if (fmCache) return fmCache;
    var RNm = safe(function () { return V.externals.ReactNative; }) || {};
    var srcs = [
      ["proxy", function (n) { return safe(function () { return globalThis.nativeModuleProxy[n]; }); }],
      ["NM", function (n) { return safe(function () { return RNm.NativeModules[n]; }); }],
      ["TM", function (n) { return safe(function () { return RNm.TurboModuleRegistry.get(n); }); }],
    ];
    var seen = [];
    for (var i = 0; i < srcs.length; i++) {
      for (var j = 0; j < FM_NAMES.length; j++) {
        var n = FM_NAMES[j], m = srcs[i][1](n);
        if (!m) continue;
        var methods = safe(function () { return Object.keys(m).filter(function (k) { return typeof m[k] === "function"; }).slice(0, 12).join("/"); }, "") || "?";
        seen.push(srcs[i][0] + ":" + n + "(" + methods + ")");
        var consts = safe(function () { return typeof m.getConstants === "function" ? m.getConstants() : {}; }, {}) || {};
        var docs = consts.DocumentsDirPath || consts.DocumentDirectoryPath || m.DocumentDirectoryPath || m.DocumentsDirPath || "";
        if (typeof m.writeFile === "function" && typeof m.readFile === "function") {
          var rnfs = typeof m.DocumentDirectoryPath === "string" || (!consts.DocumentsDirPath && consts.DocumentDirectoryPath);
          fmCache = { m: m, docs: docs, rnfs: !!rnfs };
          return fmCache;
        }
      }
    }
    var scan = [];
    [["proxy", safe(function () { return globalThis.nativeModuleProxy; })], ["NM", RNm.NativeModules]].forEach(function (pair) {
      var keys = safe(function () { return Object.keys(pair[1]); }, []) || [];
      var hit = keys.filter(function (k) { return /file|fs|storage|document/i.test(k); }).slice(0, 8);
      scan.push(pair[0] + "[" + keys.length + "]" + (hit.length ? ":" + hit.join(",") : ""));
    });
    fmDiag = (seen.length ? seen.join(" ") : "no file module found") + " | " + scan.join(" ");
    return null;
  };
  var fsWrite = async function (name, data) {
    var fm = getFM();
    if (!fm) throw new Error(t("bk_nofs_short") + " (" + fmDiag + ")");
    var errs = [];
    var tries = [];
    if (fm.rnfs) tries.push(function () { return fm.m.writeFile(fm.docs + "/" + name, data, "utf8"); });
    else {
      tries.push(function () { return fm.m.writeFile("documents", name, data, "utf8"); });
      if (fm.docs) tries.push(function () { return fm.m.writeFile(fm.docs + "/" + name, data, "utf8"); });
    }
    for (var i = 0; i < tries.length; i++) {
      try { await tries[i](); return; } catch (err) { errs.push(errText(err)); }
    }
    throw new Error(t("bk_write_fail") + ": " + errs.join(" | "));
  };
  var fsRead = async function (name) {
    var fm = getFM();
    if (!fm) return null;
    var paths = fm.docs ? [fm.docs + "/" + name, name] : [name];
    for (var i = 0; i < paths.length; i++) {
      try {
        var r = await fm.m.readFile(paths[i], "utf8");
        if (typeof r === "string" && r.length) return r;
      } catch (_) {}
    }
    return null;
  };
  var fsRemove = async function (name) {
    var fm = getFM();
    if (!fm) return;
    try {
      if (fm.rnfs && typeof fm.m.unlink === "function") await fm.m.unlink(fm.docs + "/" + name);
      else if (typeof fm.m.removeFile === "function") await fm.m.removeFile("documents", name);
    } catch (_) {}
  };

  var BK_INDEX = "PerProfile.backups.json";
  var bkFile = function (id) { return "PerProfile.backup." + id + ".json"; };
  var readIndex = async function () {
    try {
      var s = await fsRead(BK_INDEX);
      var o = s ? JSON.parse(s) : null;
      if (o && Array.isArray(o.items)) return o;
    } catch (_) {}
    return { v: 1, items: [] };
  };
  var writeBackup = async function (id, kind) {
    var s = getState();
    var snap = { v: 1, time: Date.now(), lang: s.lang, profiles: s.profiles, folders: s.folders || [], ns: s.ns };
    var data = JSON.stringify(snap);
    await fsWrite(bkFile(id), data);
    var idx = await readIndex();
    idx.items = idx.items.filter(function (x) { return x.id !== id; });
    idx.items.push({ id: id, kind: kind, time: snap.time, count: Object.keys(snap.profiles).length, size: data.length });
    idx.items.sort(function (a, b) { return b.time - a.time; });
    var manual = idx.items.filter(function (x) { return x.kind === "manual"; });
    manual.slice(10).forEach(function (x) {
      idx.items = idx.items.filter(function (y) { return y !== x; });
      fsRemove(bkFile(x.id));
    });
    await fsWrite(BK_INDEX, JSON.stringify(idx));
    return snap;
  };
  var createBackup = async function () {
    var n = Object.keys(getState().profiles).length;
    if (!n) throw new Error(t("bk_none_to_save"));
    await writeBackup("m" + Date.now().toString(36), "manual");
    return t("bk_created", { n: n });
  };
  var readBackup = async function (id) {
    var s = await fsRead(bkFile(id));
    if (!s) throw new Error(t("bk_read_fail"));
    var o;
    try { o = JSON.parse(s); } catch (_) { throw new Error(t("bk_read_fail")); }
    if (!o || typeof o.profiles !== "object") throw new Error(t("bk_read_fail"));
    return o;
  };
  var restoreBackup = async function (id, mode) {
    var o = await readBackup(id);
    var s = getState();
    if (mode === "merge") {
      var p = Object.assign({}, s.profiles);
      var added = 0, skipped = 0;
      Object.keys(o.profiles).forEach(function (n) {
        if (p[n]) skipped++; else { p[n] = o.profiles[n]; added++; }
      });
      var fl = (s.folders || []).slice();
      (o.folders || []).forEach(function (f) { if (fl.indexOf(f) < 0) fl.push(f); });
      setState({ profiles: p, folders: fl });
      return t("bk_merged", { a: added, s: skipped });
    }
    var patch = { profiles: o.profiles, folders: o.folders || [] };
    if (o.ns) patch.ns = Object.assign({}, DEFAULTS.ns, o.ns);
    if (o.lang === "ar" || o.lang === "en") patch.lang = o.lang;
    setState(patch);
    return t("bk_restored", { c: Object.keys(o.profiles).length });
  };
  var deleteBackup = async function (id) {
    var idx = await readIndex();
    idx.items = idx.items.filter(function (x) { return x.id !== id; });
    await fsRemove(bkFile(id));
    await fsWrite(BK_INDEX, JSON.stringify(idx));
  };
  var autoTimer = null;
  var scheduleAuto = function () {
    if (getState().autoBackup === false || !getFM()) return;
    clearTimeout(autoTimer);
    autoTimer = setTimeout(async function () {
      try {
        if (!Object.keys(getState().profiles).length) return;
        await writeBackup("auto", "auto");
      } catch (_) {}
    }, 3500);
  };
  var autoRestore = async function () {
    try {
      var s = getState();
      if (s.autoBackup === false || !getFM()) return;
      if (Object.keys(s.profiles).length) return;
      var idx = await readIndex();
      if (!idx.items.length) return;
      var o = await readBackup(idx.items[0].id);
      var patch = { profiles: o.profiles, folders: o.folders || [] };
      if (o.ns) patch.ns = Object.assign({}, DEFAULTS.ns, o.ns);
      if (o.lang === "ar" || o.lang === "en") patch.lang = o.lang;
      setState(patch);
      toast(t("bk_autorestored", { c: Object.keys(o.profiles).length }));
    } catch (_) {}
  };
  var fmtTime = function (ts) { return safe(function () { return new Date(ts).toLocaleString(); }, String(ts)); };
  var bkSub = function (it) {
    return t("bk_sub", { c: it.count, kb: Math.max(1, Math.round(it.size / 1024)), d: fmtTime(it.time) });
  };

  // ===== نافذة البطاقات (/show_per) =====
  const SHEET_KEY = "per-profiles-sheet";
  let sheetUI = null;

  const C = {
    bg: "#1e1f22", sheet: "#2b2d31", box: "#232428", line: "#3f4147", text: "#f2f3f5", sub: "#b5bac1",
    blurple: "#5865f2", green: "#248046", red: "#da373c", gray: "#4e5058", orange: "#c27c0e",
  };
  const toHex = (n) => "#" + Number(n).toString(16).padStart(6, "0");
  const decoUrl = (asset) =>
    "https://cdn.discordapp.com/avatar-decoration-presets/" + asset + ".png?size=160&passthrough=true";

  const makeSheetUI = () => {
    const U = ui();
    const React = U.R;
    const h = React.createElement;
    const { View, Text, Image, ScrollView, TouchableOpacity, TextInput, Dimensions } = U.RN;
    if (!View || !Text || !Image || !ScrollView || !TouchableOpacity || !TextInput || !Dimensions)
      throw new Error("RN components missing");

    function ProfileCard({ d, name, W }) {
      const bannerH = Math.round(W / 2.5);
      const AV = 84;
      const tc = d.theme_colors;
      const accent = tc && tc[1] != null ? toHex(tc[1]) : d.accent_color != null ? toHex(d.accent_color) : C.blurple;
      const bannerSrc = d.bannerUrl || d.banner;
      const avatarSrc = d.avatarUrl || d.avatar;
      const ns = d.display_name_styles;
      const nameColors = ns && Array.isArray(ns.colors) ? ns.colors : [];
      const nameColor = nameColors[0] != null ? toHex(nameColors[0]) : C.text;
      const colors = [];
      (d.theme_colors || []).forEach((c) => colors.push(c));
      if (d.accent_color != null && colors.indexOf(d.accent_color) < 0) colors.push(d.accent_color);
      const deco = d.avatar_decoration && d.avatar_decoration.asset;

      const label = (s) =>
        h(Text, { style: { color: C.sub, fontSize: 10, fontWeight: "700", marginBottom: 8, textAlign: "center" } }, s);
      const box = (key, title, children) =>
        h(View, {
          key,
          style: { flex: 1, backgroundColor: C.box, borderRadius: 12, borderWidth: 1, borderColor: C.line, padding: 6, marginHorizontal: 2, minHeight: 86, alignItems: "center" },
        }, [label(title), children]);
      const dots = (arr, size) =>
        h(View, { style: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center" } },
          arr.slice(0, 6).map((c, i) =>
            h(View, { key: "dot" + i, style: { width: size, height: size, borderRadius: size / 2, backgroundColor: toHex(c), margin: 2, borderWidth: 1, borderColor: "#ffffff55" } })
          ));
      const dash = h(Text, { style: { color: C.sub } }, "—");

      return h(View, {
        style: { width: W, backgroundColor: C.bg, borderRadius: 18, overflow: "hidden", borderWidth: 1, borderColor: C.line },
      }, [
        bannerSrc
          ? h(Image, { key: "b", source: { uri: bannerSrc }, style: { width: W, height: bannerH }, resizeMode: "cover" })
          : h(View, { key: "b", style: { width: W, height: bannerH, backgroundColor: accent } }),
        h(View, { key: "av", style: { paddingHorizontal: 16 } },
          h(View, { style: { width: AV, height: AV, marginTop: -AV / 2, alignItems: "center", justifyContent: "center" } }, [
            h(View, {
              key: "ring",
              style: { width: AV, height: AV, borderRadius: AV / 2, borderWidth: 5, borderColor: C.bg, backgroundColor: C.gray, overflow: "hidden" },
            }, avatarSrc ? h(Image, { source: { uri: avatarSrc }, style: { width: "100%", height: "100%" } }) : null),
            deco ? h(Image, { key: "deco", source: { uri: decoUrl(deco) }, style: { position: "absolute", width: AV * 1.2, height: AV * 1.2 } }) : null,
          ])),
        h(View, { key: "info", style: { paddingHorizontal: 16, paddingTop: 8, paddingBottom: 6 } }, [
          h(Text, { key: "n", style: { color: nameColor, fontSize: 21, fontWeight: "800" } }, d.nick || name),
          d.pronouns ? h(Text, { key: "p", style: { color: C.sub, fontSize: 13, marginTop: 2 } }, d.pronouns) : null,
          d.bio ? h(Text, { key: "bio", style: { color: C.text, fontSize: 14, marginTop: 8 } }, d.bio) : null,
        ]),
        h(View, { key: "boxes", style: { flexDirection: "row", padding: 8, paddingTop: 8 } }, [
          box("c", t("card_colors"), colors.length ? dots(colors, 20) : dash),
          box("e", t("card_effect"), d.profile_effect_id
            ? h(View, { style: { width: 40, height: 40, borderRadius: 12, backgroundColor: accent + "55", borderWidth: 1, borderColor: accent, alignItems: "center", justifyContent: "center" } },
                h(Text, { style: { fontSize: 20 } }, "✨"))
            : dash),
          box("d", t("card_deco"), deco ? h(Image, { source: { uri: decoUrl(deco) }, style: { width: 44, height: 44 } }) : dash),
          box("s", t("card_ns"), ns
            ? h(View, { style: { alignItems: "center" } }, [
                nameColors.length ? dots(nameColors, 16) : null,
                ns.font_id != null ? h(Text, { key: "f", style: { color: C.sub, fontSize: 10, marginTop: 2 } }, t("card_font", { id: ns.font_id })) : null,
                ns.effect_id != null ? h(Text, { key: "ef", style: { color: C.sub, fontSize: 10 } }, t("card_fx", { id: ns.effect_id })) : null,
              ])
            : dash),
        ]),
      ]);
    }

    function SheetView(props) {
      const W = Dimensions.get("window").width - 88;
      const initial = props.initSel && getState().profiles[props.initSel] ? props.initSel : null;
      const [sel, setSel] = React.useState(initial);
      const [filter, setFilter] = React.useState("all");
      const [busy, setBusy] = React.useState(false);
      const [confirmDel, setConfirmDel] = React.useState(false);
      const [, bump] = React.useState(0);
      const [editing, setEditing] = React.useState(!!props.initEdit && !!initial);
      const [nameIn, setNameIn] = React.useState(props.initEdit && initial ? initial : "");
      const [nickIn, setNickIn] = React.useState(props.initEdit && initial ? (getState().profiles[initial] || {}).nick || "" : "");
      const [folderIn, setFolderIn] = React.useState(props.initEdit && initial ? folderOf(getState().profiles[initial]) : "");

      const all = getState().profiles;
      const folders = allFolders();
      const showFilters = folders.length > 0 || Object.keys(all).some((n) => isFav(all[n]));
      const match = (n) =>
        filter === "all" ? true : filter === "fav" ? isFav(all[n]) : folderOf(all[n]) === filter.slice(2);
      const names = sortedNames(Object.keys(all).filter(match));
      const current = sel && all[sel] && names.indexOf(sel) >= 0 ? sel : names[0] || null;
      const d = current ? all[current] : null;

      const button = (key, text, onPress, bg) =>
        h(TouchableOpacity, {
          key, onPress,
          style: { flex: 1, backgroundColor: bg, paddingVertical: 14, borderRadius: 12, alignItems: "center", marginHorizontal: 4 },
        }, h(Text, { style: { color: "#fff", fontSize: 15, fontWeight: "700" } }, text));

      const input = (key, title, value, onChange, placeholder) =>
        h(View, { key, style: { marginBottom: 10 } }, [
          h(Text, { key: "l", style: { color: C.sub, fontSize: 12, fontWeight: "700", marginBottom: 4 } }, title),
          h(TextInput, {
            key: "i", value, onChangeText: onChange, placeholder, placeholderTextColor: C.gray,
            style: { backgroundColor: C.box, color: C.text, borderRadius: 10, borderWidth: 1, borderColor: C.line, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15 },
          }),
        ]);

      const chip = (key, text, active, onPress, border) =>
        h(TouchableOpacity, {
          key, onPress,
          style: { backgroundColor: active ? C.blurple : C.box, paddingVertical: 9, paddingHorizontal: 16, borderRadius: 20, marginRight: 8, borderWidth: 1, borderColor: border || (active ? C.blurple : C.line) },
        }, h(Text, { style: { color: "#fff", fontWeight: "700" } }, text));

      const row = (key, children) =>
        h(ScrollView, { key, horizontal: true, showsHorizontalScrollIndicator: false, style: { flexGrow: 0, marginBottom: 12 } }, children);

      const startEdit = () => {
        setNameIn(current);
        setNickIn((d && d.nick) || "");
        setFolderIn(folderOf(d));
        setConfirmDel(false);
        setEditing(true);
      };

      const saveEdit = () => {
        const nn = nameIn.trim();
        if (!nn) return toast(t("name_empty"));
        try {
          renameProfile(current, nn, nickIn.trim());
          setFolderOf(nn, folderIn);
        } catch (err) {
          return toast((err && err.message) || t("save_fail"));
        }
        setSel(nn);
        setEditing(false);
        bump((x) => x + 1);
        toast(t("edit_saved"));
      };

      const doApply = async () => {
        if (busy) return;
        if (!props.guildId) {
          props.close();
          return sendLocal(props.ctx, t("need_server"));
        }
        setBusy(true);
        let notes = [];
        try {
          notes = await applyProfile(d, props.guildId);
        } catch (err) {
          notes = [(err && err.message) || errText(err)];
        }
        setBusy(false);
        props.close();
        sendLocal(props.ctx, t("applied", { name: current }) + (notes.length ? "\n" + notes.join("\n") : " ✅"));
      };

      let filters = null;
      if (showFilters) {
        const fl = [chip("f-all", t("all_f"), filter === "all", () => setFilter("all")),
          chip("f-fav", "★ " + t("fav_short"), filter === "fav", () => setFilter("fav"))];
        folders.forEach((f) => fl.push(chip("f-" + f, "📁 " + f, filter === "f:" + f, () => setFilter("f:" + f))));
        filters = row("filters", fl);
      }

      const chips = row("chips", names.map((n) =>
        chip("chip-" + n, (isFav(all[n]) ? "★ " : "") + n, n === current, () => {
          setSel(n); setConfirmDel(false); setEditing(false);
        })
      ));

      let bottom;
      if (editing && current) {
        bottom = [
          h(View, { key: "form", style: { marginTop: 14 } }, [
            input("n", t("saved_name_label"), nameIn, setNameIn, t("profile_name")),
            input("k", t("display_label"), nickIn, setNickIn, "displayName"),
            input("f", t("folder_label"), folderIn, setFolderIn, t("folder_ph")),
            folders.length
              ? row("fq", [chip("q-none", t("no_folder"), !folderIn.trim(), () => setFolderIn(""))].concat(
                  folders.map((f) => chip("q-" + f, "📁 " + f, folderIn.trim() === f, () => setFolderIn(f)))))
              : null,
          ]),
          h(View, { key: "btns", style: { flexDirection: "row" } }, [
            button("save", t("save_btn"), saveEdit, C.green),
            button("cancel", t("cancel"), () => setEditing(false), C.gray),
          ]),
        ];
      } else {
        bottom = [
          h(View, { key: "btns", style: { flexDirection: "row", marginTop: 14 } }, [
            button("apply", busy ? t("busy") : t("apply_btn"), doApply, C.green),
            button("edit", t("edit_btn"), startEdit, C.blurple),
            button("del", confirmDel ? t("confirm_btn") : t("delete_btn"), () => {
              if (!confirmDel) return setConfirmDel(true);
              deleteProfile(current);
              setConfirmDel(false);
              setSel(null);
              bump((x) => x + 1);
            }, C.red),
          ]),
          h(View, { key: "btns2", style: { flexDirection: "row", marginTop: 8 } }, [
            button("fav", isFav(d) ? t("fav_on") : t("fav_off"), () => {
              try { toggleFav(current); } catch (err) { toast((err && err.message) || t("save_fail")); }
              bump((x) => x + 1);
            }, isFav(d) ? C.orange : C.gray),
            button("close", t("close"), props.close, C.gray),
          ]),
        ];
      }

      const empty = !Object.keys(all).length;
      return h(View, {
        style: { backgroundColor: C.sheet, borderRadius: 20, paddingTop: 14, paddingBottom: 26, paddingHorizontal: 16, maxHeight: Dimensions.get("window").height * 0.88 },
      }, empty
        ? [
            h(Text, { key: "e", style: { color: C.text, textAlign: "center", fontSize: 16, marginVertical: 24 } }, t("list_none") + "\n" + t("save_hint")),
            h(View, { key: "r", style: { flexDirection: "row" } }, button("c", t("close"), props.close, C.gray)),
          ]
        : [
            filters,
            names.length ? chips : h(Text, { key: "nm", style: { color: C.sub, textAlign: "center", marginVertical: 20 } }, t("no_match")),
            d ? h(ScrollView, { key: "card", style: { flexGrow: 0 }, showsVerticalScrollIndicator: false }, h(ProfileCard, { d, name: current, W })) : null,
            d ? bottom[0] : null,
            d ? bottom[1] : null,
            d ? bottom[2] || null : h(View, { key: "cl", style: { flexDirection: "row" } }, button("c", t("close"), props.close, C.gray)),
          ]);
    }

    return { SheetView };
  };

  const openSheet = (ctx, opts) => {
    opts = opts || {};
    try {
      const U = ui();
      const D = U.D;
      const AC = safe(() => V.discord.actions.AlertActionCreators);
      if (!AC || !AC.openAlert || !D.AlertModal || !D.AlertActionButton) throw new Error("no alert");
      if (!sheetUI) sheetUI = makeSheetUI();
      const h = U.R.createElement;
      const close = () => {
        safe(() => AC.dismissAlert && AC.dismissAlert(SHEET_KEY));
        safe(() => AC.closeAlert && AC.closeAlert(SHEET_KEY));
      };
      AC.openAlert(
        SHEET_KEY,
        h(D.AlertModal, {
          title: "Per Profile",
          extraContent: h(sheetUI.SheetView, {
            ctx,
            close,
            guildId: (ctx && ctx.guild && ctx.guild.id) || currentGuildId(),
            initSel: opts.sel,
            initEdit: opts.edit,
          }),
          actions: h(D.AlertActionButton, { text: t("close"), variant: "secondary" }),
        })
      );
      return true;
    } catch (err) {
      sendLocal(ctx, listText());
      return false;
    }
  };

  // ===== أوامر slash =====
  var argOf = function (args, n) {
    var a = args && args.find ? args.find(function (x) { return x.name === n; }) : null;
    return a ? a.value : undefined;
  };

  var opt = function (name, desc, type, required, choices) {
    var o = {
      name: name, displayName: name, serverLocalizedName: name, untranslatedName: name,
      description: desc, displayDescription: desc, serverLocalizedDescription: desc, untranslatedDescription: desc,
      type: type, required: !!required,
    };
    if (choices) {
      o.choices = choices.map(function (c) {
        var v = typeof c === "string" ? c : c.value;
        var l = typeof c === "string" ? c : c.label;
        return { name: v, displayName: l, serverLocalizedName: l, untranslatedName: l, label: l, value: v };
      });
    }
    return o;
  };

  var listText = function () {
    var p = getState().profiles;
    var names = sortedNames();
    if (!names.length) return t("list_none");
    return t("list_head", { n: names.length }) + "\n" + names.map(function (n, i) {
      var fo = folderOf(p[n]);
      return (i + 1) + ". " + (isFav(p[n]) ? "★ " : "") + "**" + n + "**" + (fo ? " 📁" + fo : "") + " — " + summary(p[n]);
    }).join("\n");
  };

  var buildCommands = function () { return [
    ["save_pr", t("c_save"), [opt("name", t("o_name"), 3, true)],
      function (a) { return saveCurrent(argOf(a, "name")); }],
    ["set_pr", t("c_set"), [opt("name", t("o_name"), 3, false)],
      function (a, ctx) { var n = argOf(a, "name"); if (n) return applyByName(n); openSheet(ctx); return ""; }],
    ["show_per", t("c_show"), [],
      function (a, ctx) { openSheet(ctx); return ""; }],
    ["edit_per", t("c_edit"),
      [opt("name", t("o_name"), 3, true), opt("new_name", t("o_newname"), 3, false), opt("display_name", t("o_display"), 3, false)],
      function (a, ctx) {
        var n = argOf(a, "name"), nn = argOf(a, "new_name"), dn = argOf(a, "display_name");
        var d = getState().profiles[n];
        if (!d) throw new Error(t("e_nf", { n: n }));
        if (nn == null && dn == null) { openSheet(ctx, { sel: n, edit: true }); return ""; }
        var nick = d.nick;
        if (dn != null) { var v = String(dn).trim(); nick = v === "" || v === "-" ? null : v; }
        var finalName = nn && String(nn).trim() ? String(nn).trim() : n;
        renameProfile(n, finalName, nick);
        return t("edited", { n: finalName });
      }],
    ["rename_pr", t("c_rename"), [opt("name", t("o_cur"), 3, true), opt("new_name", t("o_new"), 3, true)],
      function (a) {
        var n = argOf(a, "name"), nn = String(argOf(a, "new_name") || "").trim();
        var d = getState().profiles[n];
        if (!d) throw new Error(t("e_nf", { n: n }));
        if (!nn) throw new Error(t("e_typenew"));
        renameProfile(n, nn, d.nick);
        return t("renamed", { a: n, b: nn });
      }],
    ["delete_pr", t("c_delete"), [opt("name", t("o_name"), 3, true)],
      function (a) {
        var n = argOf(a, "name");
        if (!getState().profiles[n]) throw new Error(t("e_nf", { n: n }));
        deleteProfile(n);
        return t("deleted", { n: n });
      }],
    ["stole_per", t("c_steal"),
      [opt("user", t("o_user"), 6, true), opt("name", t("o_saveas"), 3, false), opt("apply", t("o_applynow"), 5, false)],
      function (a) { return stealUser(argOf(a, "user"), argOf(a, "name") || null, !!argOf(a, "apply")); }],
    ["key_per", t("c_key"),
      [opt("action", t("o_action"), 3, true, [{ value: "take", label: "take key" }, { value: "insert", label: "Insert the key" }]),
       opt("key", t("o_key"), 3, false),
       opt("name", t("o_keyname"), 3, false)],
      function (a) {
        if (argOf(a, "action") === "insert") {
          var k = argOf(a, "key");
          if (!k) throw new Error(t("e_pastekey"));
          return feedKeys(k);
        }
        var r = makeKey(argOf(a, "name") || null);
        if (r.parts.length === 1) copyText(r.parts[0]);
        return [keyTakeText(r)].concat(r.parts.map(function (x) { return "`" + x + "`"; }));
      }],
    ["fav_per", t("c_fav"), [opt("name", t("o_name"), 3, true)],
      function (a) {
        var n = argOf(a, "name");
        if (!getState().profiles[n]) throw new Error(t("e_nf", { n: n }));
        return toggleFav(n) ? t("fav_added", { n: n }) : t("fav_removed", { n: n });
      }],
    ["folder_per", t("c_folder"), [opt("name", t("o_name"), 3, true), opt("folder", t("o_folder"), 3, true)],
      function (a) {
        var n = argOf(a, "name");
        if (!getState().profiles[n]) throw new Error(t("e_nf", { n: n }));
        var f = setFolderOf(n, argOf(a, "folder"));
        return f ? t("folder_set", { n: n, f: f }) : t("folder_cleared", { n: n });
      }],
    ["backup_per", t("c_backup"),
      [opt("action", t("o_bk_action"), 3, true, [{ value: "create", label: "create" }, { value: "restore", label: "restore latest" }, { value: "list", label: "list" }])],
      async function (a) {
        var act = argOf(a, "action");
        if (act === "create") return createBackup();
        var idx = await readIndex();
        if (!idx.items.length) throw new Error(t("e_nobackup"));
        if (act === "restore") return restoreBackup(idx.items[0].id, "replace");
        return t("bk_list_head", { n: idx.items.length }) + "\n" + idx.items.map(function (it, i) {
          return (i + 1) + ". " + (it.kind === "auto" ? t("bk_item_auto") : t("bk_item_manual")) + " — " + bkSub(it);
        }).join("\n");
      }],
    ["random_per", t("c_random"), [],
      function () { return applyRandom(); }],
    ["newserver_per", t("c_ns"),
      [opt("mode", t("o_mode"), 3, true, ["on", "off"])],
      function (a) {
        var on = argOf(a, "mode") === "on";
        setState({ ns: Object.assign({}, getState().ns, { enabled: on }) });
        return on ? t("ns_on") : t("ns_off");
      }],
  ]; };

  var cmdState = { k: "cmd_pending", v: {} };
  var cmdText = function () { return t(cmdState.k, cmdState.v); };
  var retryCommands = null;
  var diag = function () {
    var pk = safe(function () { return Object.keys(V.plugins || {}).slice(0, 25).join(", "); }, "");
    var gk = safe(function () {
      return Object.keys(globalThis).filter(function (k) { return k.indexOf("__c") === 0 || /util/i.test(k); }).slice(0, 15).join(", ");
    }, "");
    var uk = safe(function () { return Object.keys(V.plugins.utils || {}).slice(0, 30).join(", "); }, "");
    var ck = safe(function () { return Object.keys(V.plugins.constants || {}).slice(0, 30).join(", "); }, "");
    var fk = safe(function () { var m = find("registerCommand"); return m ? "found" : "none"; }, "err");
    return "valenced.plugins: " + (pk || "—") + "\nutils: " + (uk || "—") + "\nconstants: " + (ck || "—") +
      "\nglobal: " + (gk || "—") + "\nfind(registerCommand): " + fk;
  };

  var enumValue = function (name, key, fallback) {
    try {
      var m = find(name);
      var v = m && m[name] && m[name][key];
      return v != null ? v : fallback;
    } catch (_) {
      return fallback;
    }
  };

  // رسالة محلية (ما تنرسل للقناة)
  var sendLocal = function (ctx, text) {
    var ch = ctx && ctx.channel && ctx.channel.id;
    var bm = find("sendBotMessage");
    if (bm && bm.sendBotMessage && ch) {
      try { bm.sendBotMessage(ch, text); return; } catch (_) {}
    }
    toast(String(text).split("\n")[0]);
  };

  var registerCommands = function (api) {
    var installed = false;

    var mkCmd = function (c, i) {
      var desc = c[1];
      return {
        id: String(-81000 - i),
        name: c[0], displayName: c[0], serverLocalizedName: c[0], untranslatedName: c[0],
        description: desc, displayDescription: desc, serverLocalizedDescription: desc, untranslatedDescription: desc,
        type: 1,
        inputType: enumValue("ApplicationCommandInputType", "BUILT_IN_TEXT", 1),
        applicationId: "-1",
        options: c[2],
        predicate: function () { return true; },
        execute: async function (args, ctx) {
          try {
            var out = await c[3](args, ctx);
            (Array.isArray(out) ? out : [out]).forEach(function (t) { if (t != null && t !== "") sendLocal(ctx, String(t)); });
          } catch (err) {
            sendLocal(ctx, t("err_prefix") + ((err && err.message) || errText(err)));
          }
        },
      };
    };

    var install = function () {
      if (installed) return;
      installed = true;
      var cmds = buildCommands().map(mkCmd);
      cmdState = { k: "cmd_search", v: {} };
      api.cleanup(F.getModules(F.filters.withProps("getBuiltInCommands"), function (mod) {
        api.cleanup(V.patcher.instead(mod, "getBuiltInCommands", function (args, orig) {
          var result = orig.apply(this, args);
          try {
            var types = args && args[0];
            var wantsChat = Array.isArray(types) ? types.indexOf(1) >= 0 : types == null || types === 1;
            if (!wantsChat || !Array.isArray(result)) return result;
            if (result.some(function (x) { return x && String(x.id) === cmds[0].id; })) return result;
            return result.concat(cmds);
          } catch (_) {
            return result;
          }
        }));
        cmdState = { k: "cmd_ok", v: { n: cmds.length } };
      }));
    };

    install();
    retryCommands = install;
  };

  return (
    (e.default = plugin({
      jsonStorage: { load: true, default: DEFAULTS },
      start: function (ctx) {
        store = ctx.jsonStorage;
        knownGuilds = new Set(Object.keys(safe(function () { return Stores.GuildStore.getGuilds(); }, {}) || {}));
        registerCommands(ctx);
        setTimeout(autoRestore, 1500);
        ctx.cleanup(function () { clearTimeout(autoTimer); });
        if (Dispatcher && Dispatcher.subscribe) {
          Dispatcher.subscribe("GUILD_CREATE", onGuildCreate);
          ctx.cleanup(function () { safe(function () { Dispatcher.unsubscribe("GUILD_CREATE", onGuildCreate); }); });
        }
      },
      SettingsComponent: SettingsComponent,
    })),
    e
  );
})({});
